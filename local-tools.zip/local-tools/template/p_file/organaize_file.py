# 概要:ファイルをデスクトップに「yyyymmdd-01」フォルダを作成してショートカット以外を移動する
# HTML（index.html）でボタンを押したらポップアップで下記
# 「「yyyymmdd-01」を作成し、デスクトップのファイルを整理しますが問題ないでしょうか？」
# Yesなら「yyyymmdd-01」フォルダを作成(01があるなら02として作成)
# Noならポップアップを閉じる（ポップアップはindex.htmlで表示）
from datetime import datetime
from pathlib import Path
import shutil

class UserFacingError(Exception):
    """画面にそのまま見せてよいエラー"""


def get_desktop() -> Path:
    for p in (Path.home() / "Desktop", Path.home() / "OneDrive" / "Desktop"):
        if p.is_dir():
            return p
    raise UserFacingError("デスクトップが見つかりません。")


def next_folder_name(desktop: Path) -> str:
    today = datetime.now().strftime("%Y%m%d")
    n = 1
    while (desktop / f"{today}-{n:02d}").exists():
        n += 1
    return f"{today}-{n:02d}"


def move_folder() -> Path:
    #変数設定
    desktop = get_desktop()
    shortcuts = {".lnk", ".url"}

    #デスクトップにフォルダ作成
    desktop = get_desktop()
    path = desktop / next_folder_name(desktop)
    path.mkdir()

    #フォルダへ移動
    for item in desktop.iterdir():
        #作成したフォルダならスキップ
        if item == path:
            continue
        #隠しファイルならスキップ
        if item.name.startswith(".") or item.name.lower() == "desktop.ini":
            continue
        #ショートカット以外移動
        if item.is_file():
            if item.suffix.lower() not in shortcuts:
                shutil.move(str(item), str(path / item.name))
                print(f"移動完了(ファイル): {item.name}")
        elif item.is_dir():
            shutil.move(str(item), str(path / item.name))
            print(f"移動完了(フォルダ): {item.name}")
    return path


# ショートカット以外全部移動
# 終わったらポップアップで終了を知らせる
