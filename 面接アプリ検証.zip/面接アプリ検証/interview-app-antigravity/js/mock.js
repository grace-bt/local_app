// mock.js - 模擬面接モード(F5 / S6, S7)の状態管理と進行
const Mock = (function () {
  // 状態: idle | asking | waiting | summarizing | error | done
  let state = "idle";
  let session = null;
  let mainQuestionsTarget = 5;
  let completedMainQuestions = 0;
  let currentFollowupCount = 0;
  let lastInterviewerTurnType = "question"; // "question" | "followup"

  function generateSessionId() {
    const d = new Date();
    const pad = function (n) { return n < 10 ? "0" + n : "" + n; };
    return "s_mock_" + d.getFullYear() + pad(d.getMonth() + 1) + pad(d.getDate()) + "_" +
      pad(d.getHours()) + pad(d.getMinutes()) + pad(d.getSeconds());
  }

  function getState() {
    return state;
  }

  function getSession() {
    return session;
  }

  function getProgress() {
    return {
      currentQuestionNumber: Math.min(completedMainQuestions + 1, mainQuestionsTarget),
      totalQuestions: mainQuestionsTarget,
      followupCount: currentFollowupCount,
      state: state
    };
  }

  // 模擬面接の開始
  async function startMock(options) {
    const job = options.job;
    const stageId = options.stageId;
    const stageObj = PRESETS.stages.find(function (s) { return s.id === stageId; });
    const stageName = stageObj ? stageObj.name : "一次面接";
    mainQuestionsTarget = options.questionCount || CONFIG.DEFAULT_QUESTION_COUNT;
    completedMainQuestions = 0;
    currentFollowupCount = 0;

    session = {
      id: generateSessionId(),
      mode: "mock",
      job: job,
      stage: stageName,
      startedAt: new Date().toISOString(),
      turns: [],
      summary: null
    };

    Storage.addSession(session);
    state = "asking";

    // 最初のメイン質問を取得
    return await _fetchNextInterviewerTurn(false);
  }

  // 面接官の発言を取得（メイン質問または深掘り）
  async function _fetchNextInterviewerTurn(isFollowup) {
    state = "asking";
    const profile = Storage.getProfile();
    const remainingQuestions = Math.max(0, mainQuestionsTarget - completedMainQuestions);

    const prompt = Prompts.buildInterviewerPrompt({
      job: session.job,
      stageName: session.stage,
      turns: session.turns,
      remainingQuestions: remainingQuestions,
      isFollowup: isFollowup,
      profile: profile
    });

    try {
      const result = await Gemini.callJson("interviewer", prompt, 0.7);
      const text = result.text || result.rawText || "それでは、あなたのこれまでのご経験について教えていただけますか？";

      const turn = {
        role: "interviewer",
        text: text,
        type: isFollowup ? "followup" : "question"
      };

      session.turns.push(turn);
      Storage.updateSession(session);

      lastInterviewerTurnType = turn.type;
      state = "waiting";

      return {
        turn: turn,
        progress: getProgress()
      };
    } catch (err) {
      state = "error";
      throw err;
    }
  }

  // 候補者の回答送信
  async function sendAnswer(answerText) {
    if (state !== "waiting") {
      throw { kind: "system", message: "現在は回答を受け付ける状態ではありません。" };
    }

    const trimmed = (answerText || "").trim();
    if (!trimmed) {
      throw { kind: "validation", message: "回答を入力してください。" };
    }

    // 候補者の発言を記録
    const candidateTurn = {
      role: "candidate",
      text: trimmed
    };
    session.turns.push(candidateTurn);
    Storage.updateSession(session);

    // 次のアクションの判定（深掘りするか、次のメイン質問に進むか、面接終了か）
    const shouldFollowup = (currentFollowupCount < CONFIG.MAX_FOLLOWUPS_PER_QUESTION) && (Math.random() < 0.75);

    if (shouldFollowup) {
      currentFollowupCount++;
      // 深掘り質問の取得
      return await _fetchNextInterviewerTurn(true);
    } else {
      // 深掘り終了、メイン質問1問完了
      completedMainQuestions++;
      currentFollowupCount = 0;

      if (completedMainQuestions >= mainQuestionsTarget) {
        // 設定問数終了 -> 総評生成へ
        return await finishMock();
      } else {
        // 次のメイン質問へ
        return await _fetchNextInterviewerTurn(false);
      }
    }
  }

  // 模擬面接の終了（規定問数到達または途中終了）と総評生成
  async function finishMock() {
    state = "summarizing";

    // 発言数が1つもない場合（開始直後終了など）
    const candidateAnswers = session.turns.filter(function (t) { return t.role === "candidate"; });
    if (candidateAnswers.length === 0) {
      state = "done";
      session.summary = {
        strengths: ["回答が送信されませんでした"],
        weaknesses: ["面接が途中で終了しました"],
        nextThemes: ["1問以上回答してから総評をお試しください"],
        overallAdvice: "次回はぜひ回答を入力して面接を体験してみてください。"
      };
      Storage.updateSession(session);
      return { finished: true, summary: session.summary };
    }

    const profile = Storage.getProfile();
    const prompt = Prompts.buildSummaryPrompt({
      job: session.job,
      stageName: session.stage,
      turns: session.turns,
      profile: profile
    });

    try {
      const summary = await Gemini.callJson("summary", prompt, 0.4);
      session.summary = summary;
      session.completedAt = new Date().toISOString();
      Storage.updateSession(session);
      state = "done";

      return {
        finished: true,
        summary: summary,
        session: session
      };
    } catch (err) {
      state = "error";
      throw err;
    }
  }

  // エラー時の再試行
  async function retryLastAction() {
    if (state === "error") {
      // 直前が質問取得中だった場合
      return await _fetchNextInterviewerTurn(lastInterviewerTurnType === "followup");
    }
    return null;
  }

  return {
    getState: getState,
    getSession: getSession,
    getProgress: getProgress,
    startMock: startMock,
    sendAnswer: sendAnswer,
    finishMock: finishMock,
    retryLastAction: retryLastAction
  };
})();
