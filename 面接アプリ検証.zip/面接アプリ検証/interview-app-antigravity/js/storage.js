// storage.js - localStorageの安全な読み書き・インポート・エクスポート
const Storage = (function () {
  const KEYS = {
    SETTINGS: "ib.settings",
    SESSIONS: "ib.sessions",
    QUESTIONS: "ib.questions",
    PROFILE: "ib.profile"
  };

  function _get(key, defaultValue) {
    try {
      const data = localStorage.getItem(key);
      if (data === null || data === undefined) return defaultValue;
      return JSON.parse(data);
    } catch (e) {
      console.warn("Storage read error for key " + key + ":", e);
      return defaultValue;
    }
  }

  function _set(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (e) {
      console.error("Storage write error for key " + key + ":", e);
      throw { kind: "storage", message: "ローカルストレージへの書き込みに失敗しました（容量制限の可能性があります）。" };
    }
  }

  // --- 設定管理 (ib.settings) ---
  function getSettings() {
    const defaults = {
      apiKey: "",
      model: CONFIG.DEFAULT_MODEL,
      questionCount: CONFIG.DEFAULT_QUESTION_COUNT,
      lastJob: "",
      lastStage: "first"
    };
    const stored = _get(KEYS.SETTINGS, {});
    return Object.assign({}, defaults, stored);
  }

  function saveSettings(newSettings) {
    const current = getSettings();
    const updated = Object.assign({}, current, newSettings);
    _set(KEYS.SETTINGS, updated);
    return updated;
  }

  function clearApiKey() {
    const settings = getSettings();
    settings.apiKey = "";
    _set(KEYS.SETTINGS, settings);
    return settings;
  }

  // --- プロフィール管理 (ib.profile) - F7任意 ---
  function getProfile() {
    return _get(KEYS.PROFILE, {
      summary: "",       // 職務経歴要約
      motivation: "",    // 転職理由・志望動機
      strengths: "",     // 強み・マネジメント/課長経験等
      aiBackground: ""   // AI関連の取り組み・学習状況
    });
  }

  function saveProfile(profile) {
    return _set(KEYS.PROFILE, profile);
  }

  // --- 履歴セッション管理 (ib.sessions) ---
  function listSessions() {
    const list = _get(KEYS.SESSIONS, []);
    return Array.isArray(list) ? list : [];
  }

  function getSession(sessionId) {
    const sessions = listSessions();
    return sessions.find(function (s) { return s.id === sessionId; }) || null;
  }

  function addSession(session) {
    const sessions = listSessions();
    // 先頭に追加 (新しい順)
    sessions.unshift(session);
    // 上限超過時は古いものを切り捨て
    if (sessions.length > CONFIG.MAX_SESSIONS_SAVED) {
      sessions.length = CONFIG.MAX_SESSIONS_SAVED;
    }
    _set(KEYS.SESSIONS, sessions);
    return session;
  }

  function updateSession(session) {
    const sessions = listSessions();
    const index = sessions.findIndex(function (s) { return s.id === session.id; });
    if (index !== -1) {
      sessions[index] = session;
      _set(KEYS.SESSIONS, sessions);
    } else {
      addSession(session);
    }
    return session;
  }

  function deleteSession(sessionId) {
    let sessions = listSessions();
    sessions = sessions.filter(function (s) { return s.id !== sessionId; });
    _set(KEYS.SESSIONS, sessions);
    return sessions;
  }

  function clearAllSessions() {
    _set(KEYS.SESSIONS, []);
  }

  // --- 生成済み質問 (ib.questions) - 重複回避用 ---
  function listQuestions() {
    return _get(KEYS.QUESTIONS, []);
  }

  function addQuestions(questions, jobName) {
    const list = listQuestions();
    const now = new Date().toISOString();
    questions.forEach(function (q) {
      list.push({
        text: q.text || q,
        category: q.category || "",
        job: jobName || "",
        createdAt: now
      });
    });
    // 直近上限を保つ
    const max = CONFIG.RECENT_QUESTIONS_LIMIT * 2;
    if (list.length > max) {
      list.splice(0, list.length - max);
    }
    _set(KEYS.QUESTIONS, list);
  }

  function getRecentQuestionsForJob(jobName) {
    const list = listQuestions();
    return list
      .filter(function (q) { return !jobName || q.job === jobName; })
      .slice(-CONFIG.RECENT_QUESTIONS_LIMIT)
      .map(function (q) { return q.text; });
  }

  // --- エクスポート / インポート (セキュリティ: APIキーは含めない) ---
  function exportAll() {
    const data = {
      version: 1,
      exportedAt: new Date().toISOString(),
      sessions: listSessions(),
      questions: listQuestions(),
      profile: getProfile(),
      settings: {
        model: getSettings().model,
        questionCount: getSettings().questionCount,
        lastJob: getSettings().lastJob,
        lastStage: getSettings().lastStage
        // 注意: apiKeyは意図的に除外
      }
    };
    return JSON.stringify(data, null, 2);
  }

  function importAll(jsonString) {
    try {
      const data = JSON.parse(jsonString);
      if (!data || typeof data !== "object") {
        throw new Error("無効なJSONフォーマットです");
      }
      if (Array.isArray(data.sessions)) {
        _set(KEYS.SESSIONS, data.sessions);
      }
      if (Array.isArray(data.questions)) {
        _set(KEYS.QUESTIONS, data.questions);
      }
      if (data.profile && typeof data.profile === "object") {
        _set(KEYS.PROFILE, data.profile);
      }
      if (data.settings && typeof data.settings === "object") {
        const current = getSettings();
        // 既存のAPIキーを保護した上で設定をマージ
        current.model = data.settings.model || current.model;
        current.questionCount = data.settings.questionCount || current.questionCount;
        current.lastJob = data.settings.lastJob || current.lastJob;
        current.lastStage = data.settings.lastStage || current.lastStage;
        _set(KEYS.SETTINGS, current);
      }
      return { success: true };
    } catch (e) {
      return { success: false, error: e.message || "インポートに失敗しました" };
    }
  }

  function clearAllData() {
    localStorage.removeItem(KEYS.SETTINGS);
    localStorage.removeItem(KEYS.SESSIONS);
    localStorage.removeItem(KEYS.QUESTIONS);
    localStorage.removeItem(KEYS.PROFILE);
  }

  return {
    getSettings: getSettings,
    saveSettings: saveSettings,
    clearApiKey: clearApiKey,
    getProfile: getProfile,
    saveProfile: saveProfile,
    listSessions: listSessions,
    getSession: getSession,
    addSession: addSession,
    updateSession: updateSession,
    deleteSession: deleteSession,
    clearAllSessions: clearAllSessions,
    listQuestions: listQuestions,
    addQuestions: addQuestions,
    getRecentQuestionsForJob: getRecentQuestionsForJob,
    exportAll: exportAll,
    importAll: importAll,
    clearAllData: clearAllData
  };
})();
