// ui.js - 画面切り替え、DOM描画、エラーバナー、セキュリティ配慮の描画管理
const UI = (function () {
  const screens = {
    top: document.getElementById("screen-top"),
    settings: document.getElementById("screen-settings"),
    setup: document.getElementById("screen-setup"),
    practice: document.getElementById("screen-practice"),
    feedback: document.getElementById("screen-feedback"),
    mock: document.getElementById("screen-mock"),
    summary: document.getElementById("screen-summary"),
    history: document.getElementById("screen-history")
  };

  let activeMode = "practice"; // "practice" | "mock"
  let currentRetryHandler = null;

  // 画面切り替え (S1〜S8)
  function showScreen(screenId) {
    hideError();
    hideLoading();
    Object.keys(screens).forEach(function (key) {
      if (screens[key]) {
        screens[key].classList.toggle("hidden", key !== screenId);
      }
    });
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  // 読み込み表示の制御
  function showLoading(message) {
    const overlay = document.getElementById("loading-overlay");
    const textElem = document.getElementById("loading-text");
    if (textElem) {
      textElem.textContent = message || "AIが思考中...";
    }
    if (overlay) {
      overlay.classList.remove("hidden");
    }
  }

  function hideLoading() {
    const overlay = document.getElementById("loading-overlay");
    if (overlay) {
      overlay.classList.add("hidden");
    }
  }

  // エラーバナーの表示
  function showError(errorObj, retryCallback) {
    const banner = document.getElementById("error-banner");
    const messageElem = document.getElementById("error-message");
    const retryBtn = document.getElementById("error-retry-btn");
    const linkBtn = document.getElementById("error-link-btn");

    if (!banner || !messageElem) return;

    const kind = errorObj.kind || "unknown";
    let msg = errorObj.message || "エラーが発生しました。";

    // エラー種類に応じた追加案内
    if (kind === "auth") {
      msg = "【認証エラー】" + msg;
      if (linkBtn) {
        linkBtn.classList.remove("hidden");
        linkBtn.textContent = "設定画面を開く";
        linkBtn.onclick = function () {
          banner.classList.add("hidden");
          showScreen("settings");
        };
      }
    } else {
      if (linkBtn) linkBtn.classList.add("hidden");
    }

    if (kind === "rate") {
      msg = "【制限超過】" + msg + "（無料枠の利用枠制限です。約1分後に再試行してください）";
    }

    messageElem.textContent = msg;

    currentRetryHandler = retryCallback;
    if (retryBtn) {
      if (typeof retryCallback === "function") {
        retryBtn.classList.remove("hidden");
        retryBtn.onclick = async function () {
          hideError();
          try {
            await currentRetryHandler();
          } catch (e) {
            showError(e, currentRetryHandler);
          }
        };
      } else {
        retryBtn.classList.add("hidden");
      }
    }

    banner.classList.remove("hidden");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function hideError() {
    const banner = document.getElementById("error-banner");
    if (banner) {
      banner.classList.add("hidden");
    }
    currentRetryHandler = null;
  }

  // S1 トップ画面の初期化・状態更新
  function updateTopScreen() {
    const settings = Storage.getSettings();
    const hasKey = !!settings.apiKey;

    const btnPractice = document.getElementById("btn-start-practice");
    const btnMock = document.getElementById("btn-start-mock");
    const keyWarning = document.getElementById("top-key-warning");

    if (btnPractice) btnPractice.disabled = !hasKey;
    if (btnMock) btnMock.disabled = !hasKey;
    if (keyWarning) keyWarning.classList.toggle("hidden", hasKey);
  }

  // S2 設定画面の初期化
  function initSettingsScreen() {
    const settings = Storage.getSettings();
    const inputKey = document.getElementById("setting-api-key");
    const selectModel = document.getElementById("setting-model");
    const inputCount = document.getElementById("setting-question-count");
    const statusMsg = document.getElementById("setting-status-msg");

    if (statusMsg) statusMsg.textContent = "";

    // モデルセレクトの生成
    if (selectModel) {
      selectModel.innerHTML = "";
      CONFIG.AVAILABLE_MODELS.forEach(function (m) {
        const opt = document.createElement("option");
        opt.value = m.id;
        opt.textContent = m.name;
        if (m.id === settings.model) opt.selected = true;
        selectModel.appendChild(opt);
      });
    }

    if (inputKey) {
      inputKey.value = settings.apiKey ? "********" : "";
      inputKey.dataset.hasSavedKey = settings.apiKey ? "true" : "false";
    }

    if (inputCount) {
      inputCount.value = settings.questionCount || CONFIG.DEFAULT_QUESTION_COUNT;
    }

    // プロフィール設定の読み込み (F7)
    const profile = Storage.getProfile();
    const profileSummary = document.getElementById("setting-profile-summary");
    const profileStrengths = document.getElementById("setting-profile-strengths");
    const profileAi = document.getElementById("setting-profile-ai");

    if (profileSummary) profileSummary.value = profile.summary || "";
    if (profileStrengths) profileStrengths.value = profile.strengths || "";
    if (profileAi) profileAi.value = profile.aiBackground || "";
  }

  // S3 練習設定画面の初期化
  function initSetupScreen(mode) {
    activeMode = mode || "practice";
    const titleElem = document.getElementById("setup-mode-title");
    const descElem = document.getElementById("setup-mode-desc");
    const catGroup = document.getElementById("setup-category-group");
    const countGroup = document.getElementById("setup-count-group");

    if (titleElem) {
      titleElem.textContent = activeMode === "practice" ? "質問練習の設定" : "模擬面接の設定";
    }
    if (descElem) {
      descElem.textContent = activeMode === "practice"
        ? "1問ずつ回答を入力し、AIから観点別スコアと具体的な改善案を受け取ります。"
        : "AI面接官と対話形式で質疑応答を行います。回答に応じた深掘り質問を経て、最後に総評が出ます。";
    }

    // 質問練習のときはカテゴリ選択を表示、模擬面接では全般から出題
    if (catGroup) {
      catGroup.classList.toggle("hidden", activeMode !== "practice");
    }
    if (countGroup) {
      countGroup.classList.toggle("hidden", activeMode !== "mock");
    }

    // 職種セレクトの構築
    const selectJob = document.getElementById("setup-job-select");
    const customJobInput = document.getElementById("setup-custom-job");
    const settings = Storage.getSettings();

    if (selectJob) {
      selectJob.innerHTML = '<option value="">-- 職種を選択してください --</option>';
      const optGroupAi = document.createElement("optgroup");
      optGroupAi.label = "AI関連職 (特厚プリセット)";
      const optGroupIt = document.createElement("optgroup");
      optGroupIt.label = "IT・エンジニア職";
      const optGroupOther = document.createElement("optgroup");
      optGroupOther.label = "その他";

      PRESETS.jobs.forEach(function (j) {
        const opt = document.createElement("option");
        opt.value = j.name;
        opt.textContent = j.name + " (" + j.description + ")";
        if (j.category === "ai") optGroupAi.appendChild(opt);
        else optGroupIt.appendChild(opt);
      });

      const optCustom = document.createElement("option");
      optCustom.value = "__custom__";
      optCustom.textContent = "自由入力（上記以外の職種）";
      optGroupOther.appendChild(optCustom);

      selectJob.appendChild(optGroupAi);
      selectJob.appendChild(optGroupIt);
      selectJob.appendChild(optGroupOther);

      if (settings.lastJob) {
        selectJob.value = settings.lastJob;
      }
    }

    // 面接段階セレクトの構築
    const selectStage = document.getElementById("setup-stage-select");
    if (selectStage) {
      selectStage.innerHTML = "";
      PRESETS.stages.forEach(function (s) {
        const opt = document.createElement("option");
        opt.value = s.id;
        opt.textContent = s.name + " - " + s.desc;
        if (s.id === settings.lastStage) opt.selected = true;
        selectStage.appendChild(opt);
      });
    }

    // カテゴリセレクトの構築
    const selectCat = document.getElementById("setup-category-select");
    if (selectCat) {
      selectCat.innerHTML = '<option value="">おまかせ（全カテゴリからランダム出題）</option>';
      PRESETS.categories.forEach(function (c) {
        const opt = document.createElement("option");
        opt.value = c.id;
        opt.textContent = c.name;
        selectCat.appendChild(opt);
      });
    }

    // 問数
    const inputMockCount = document.getElementById("setup-mock-count");
    if (inputMockCount) {
      inputMockCount.value = settings.questionCount || CONFIG.DEFAULT_QUESTION_COUNT;
    }
  }

  // S4 質問練習画面の描画
  function renderPracticeQuestion(data) {
    const qTextElem = document.getElementById("practice-question-text");
    const progressElem = document.getElementById("practice-progress");
    const catBadge = document.getElementById("practice-category-badge");
    const answerInput = document.getElementById("practice-answer-input");
    const charCountElem = document.getElementById("practice-char-count");

    if (qTextElem) qTextElem.textContent = data.question.text;
    if (progressElem) progressElem.textContent = "質問 " + data.index + " / " + data.total;
    if (catBadge) catBadge.textContent = data.question.category || "面接想定質問";
    if (answerInput) {
      answerInput.value = "";
      answerInput.focus();
    }
    if (charCountElem) charCountElem.textContent = "0 文字";
  }

  // S5 フィードバック画面の描画 (textContent使用でXSS防止)
  function renderFeedback(data) {
    const questionElem = document.getElementById("fb-question-text");
    const userAnsElem = document.getElementById("fb-user-answer");
    const scoresContainer = document.getElementById("fb-scores-list");
    const goodListElem = document.getElementById("fb-good-list");
    const improveListElem = document.getElementById("fb-improve-list");
    const exampleElem = document.getElementById("fb-example-text");
    const nextBtn = document.getElementById("fb-btn-next");

    if (questionElem) questionElem.textContent = data.question;
    if (userAnsElem) userAnsElem.textContent = data.answer;

    // 観点別スコア
    if (scoresContainer) {
      scoresContainer.innerHTML = "";
      const scores = data.feedback.scores || {};
      CONFIG.EVALUATION_CRITERIA.forEach(function (c) {
        const val = scores[c.key] || 3;
        const item = document.createElement("div");
        item.className = "score-card";

        const label = document.createElement("div");
        label.className = "score-label";
        label.textContent = c.key;

        const stars = document.createElement("div");
        stars.className = "score-stars";
        stars.textContent = "★".repeat(val) + "☆".repeat(5 - val);

        const valText = document.createElement("div");
        valText.className = "score-num";
        valText.textContent = val + " / 5";

        item.appendChild(label);
        item.appendChild(stars);
        item.appendChild(valText);
        scoresContainer.appendChild(item);
      });
    }

    // 良い点
    if (goodListElem) {
      goodListElem.innerHTML = "";
      (data.feedback.good || []).forEach(function (text) {
        const li = document.createElement("li");
        li.textContent = text;
        goodListElem.appendChild(li);
      });
    }

    // 改善点
    if (improveListElem) {
      improveListElem.innerHTML = "";
      (data.feedback.improve || []).forEach(function (text) {
        const li = document.createElement("li");
        li.textContent = text;
        improveListElem.appendChild(li);
      });
    }

    // 改善例
    if (exampleElem) {
      exampleElem.textContent = data.feedback.example || "(改善例はありません)";
    }

    // 次の質問ボタンの切り替え
    if (nextBtn) {
      nextBtn.textContent = data.hasNext ? "次の質問へ進む" : "練習を終了してトップへ";
    }
  }

  // S6 模擬面接画面の描画
  function renderMockTurn(turn, progress) {
    const chatContainer = document.getElementById("mock-chat-container");
    const progressElem = document.getElementById("mock-progress-badge");
    const inputElem = document.getElementById("mock-answer-input");
    const sendBtn = document.getElementById("mock-send-btn");

    if (progressElem) {
      let badgeText = "問 " + progress.currentQuestionNumber + " / " + progress.totalQuestions;
      if (progress.followupCount > 0) {
        badgeText += " (深掘り " + progress.followupCount + "回目)";
      }
      progressElem.textContent = badgeText;
    }

    // 発言吹き出しの追加
    if (chatContainer && turn) {
      const msgDiv = document.createElement("div");
      msgDiv.className = "chat-bubble " + (turn.role === "interviewer" ? "interviewer" : "candidate");

      const header = document.createElement("div");
      header.className = "bubble-author";
      header.textContent = turn.role === "interviewer"
        ? (turn.type === "followup" ? "面接官（深掘り）" : "面接官")
        : "あなた（回答）";

      const body = document.createElement("div");
      body.className = "bubble-text";
      body.textContent = turn.text; // textContentで安全に挿入

      msgDiv.appendChild(header);
      msgDiv.appendChild(body);
      chatContainer.appendChild(msgDiv);
      chatContainer.scrollTop = chatContainer.scrollHeight;
    }

    // 入力欄のリセットとフォーカス
    if (inputElem) {
      inputElem.value = "";
      inputElem.focus();
    }
    if (sendBtn) {
      sendBtn.disabled = false;
    }
  }

  function clearMockChat() {
    const chatContainer = document.getElementById("mock-chat-container");
    if (chatContainer) chatContainer.innerHTML = "";
  }

  // S7 模擬面接 総評画面の描画
  function renderSummary(summaryData, session) {
    const jobElem = document.getElementById("summary-job-title");
    const strengthsList = document.getElementById("summary-strengths-list");
    const weaknessesList = document.getElementById("summary-weaknesses-list");
    const themesList = document.getElementById("summary-themes-list");
    const adviceElem = document.getElementById("summary-overall-advice");

    if (jobElem && session) {
      jobElem.textContent = session.job + " (" + session.stage + ")";
    }

    if (strengthsList) {
      strengthsList.innerHTML = "";
      (summaryData.strengths || []).forEach(function (text) {
        const li = document.createElement("li");
        li.textContent = text;
        strengthsList.appendChild(li);
      });
    }

    if (weaknessesList) {
      weaknessesList.innerHTML = "";
      (summaryData.weaknesses || []).forEach(function (text) {
        const li = document.createElement("li");
        li.textContent = text;
        weaknessesList.appendChild(li);
      });
    }

    if (themesList) {
      themesList.innerHTML = "";
      (summaryData.nextThemes || []).forEach(function (text) {
        const li = document.createElement("li");
        li.textContent = text;
        themesList.appendChild(li);
      });
    }

    if (adviceElem) {
      adviceElem.textContent = summaryData.overallAdvice || "";
    }
  }

  // S8 履歴画面の描画
  function renderHistory() {
    const listElem = document.getElementById("history-list-container");
    const detailElem = document.getElementById("history-detail-container");
    if (!listElem) return;

    const sessions = Storage.listSessions();
    listElem.innerHTML = "";
    if (detailElem) detailElem.innerHTML = '<p class="text-muted">左側の履歴を選択すると詳細が表示されます。</p>';

    if (sessions.length === 0) {
      listElem.innerHTML = '<p class="empty-msg">まだ練習履歴がありません。</p>';
      return;
    }

    sessions.forEach(function (sess) {
      const card = document.createElement("div");
      card.className = "history-item-card";

      const timeStr = new Date(sess.startedAt).toLocaleString("ja-JP", {
        month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit"
      });

      const modeBadge = sess.mode === "mock" ? "模擬面接" : "質問練習";

      card.innerHTML =
        '<div class="history-item-header">' +
        '<span class="badge badge-' + sess.mode + '">' + modeBadge + '</span>' +
        '<span class="history-date">' + timeStr + '</span>' +
        '</div>' +
        '<div class="history-item-job">' + (sess.job || "職種未定") + ' (' + (sess.stage || "") + ')</div>' +
        '<div class="history-item-count">やりとり: ' + (sess.turns ? sess.turns.length : 0) + ' ターン</div>';

      card.onclick = function () {
        document.querySelectorAll(".history-item-card").forEach(function (c) { c.classList.remove("active"); });
        card.classList.add("active");
        renderHistoryDetail(sess);
      };

      listElem.appendChild(card);
    });
  }

  function renderHistoryDetail(session) {
    const detailElem = document.getElementById("history-detail-container");
    if (!detailElem) return;

    detailElem.innerHTML = "";

    const title = document.createElement("h3");
    title.textContent = (session.mode === "mock" ? "【模擬面接】" : "【質問練習】") + " " + session.job + " (" + session.stage + ")";
    detailElem.appendChild(title);

    const time = document.createElement("p");
    time.className = "text-muted";
    time.textContent = "日時: " + new Date(session.startedAt).toLocaleString("ja-JP");
    detailElem.appendChild(time);

    // 総評があれば表示
    if (session.summary) {
      const summaryBox = document.createElement("div");
      summaryBox.className = "history-summary-box";

      const h4 = document.createElement("h4");
      h4.textContent = "総評";
      summaryBox.appendChild(h4);

      if (session.summary.overallAdvice) {
        const advice = document.createElement("p");
        advice.textContent = session.summary.overallAdvice;
        summaryBox.appendChild(advice);
      }

      if (session.summary.strengths && session.summary.strengths.length > 0) {
        const stH5 = document.createElement("strong");
        stH5.textContent = "強み:";
        summaryBox.appendChild(stH5);
        const ul = document.createElement("ul");
        session.summary.strengths.forEach(function (s) {
          const li = document.createElement("li");
          li.textContent = s;
          ul.appendChild(li);
        });
        summaryBox.appendChild(ul);
      }

      detailElem.appendChild(summaryBox);
    }

    // 会話ターンの表示
    const turnsBox = document.createElement("div");
    turnsBox.className = "history-turns-box";

    (session.turns || []).forEach(function (t, i) {
      const turnDiv = document.createElement("div");
      turnDiv.className = "history-turn " + t.role;

      const roleHeader = document.createElement("div");
      roleHeader.className = "turn-role";
      roleHeader.textContent = t.role === "interviewer" ? "面接官: " : "回答: ";

      const turnText = document.createElement("div");
      turnText.className = "turn-text";
      turnText.textContent = t.text;

      turnDiv.appendChild(roleHeader);
      turnDiv.appendChild(turnText);

      // フィードバックがあれば展開
      if (t.feedback) {
        const fbDiv = document.createElement("div");
        fbDiv.className = "history-fb";

        if (t.feedback.scores) {
          const scoreSpans = Object.keys(t.feedback.scores).map(function (k) {
            return k + ": " + t.feedback.scores[k] + "/5";
          }).join(" | ");
          const scoreP = document.createElement("p");
          scoreP.className = "fb-scores-summary";
          scoreP.textContent = "【評価スコア】 " + scoreSpans;
          fbDiv.appendChild(scoreP);
        }

        if (t.feedback.example) {
          const exP = document.createElement("p");
          exP.className = "fb-example-summary";
          exP.textContent = "【改善例】 " + t.feedback.example;
          fbDiv.appendChild(exP);
        }

        turnDiv.appendChild(fbDiv);
      }

      turnsBox.appendChild(turnDiv);
    });

    detailElem.appendChild(turnsBox);

    // 削除ボタン
    const deleteBtn = document.createElement("button");
    deleteBtn.className = "btn btn-danger-outline btn-sm";
    deleteBtn.textContent = "この履歴を削除";
    deleteBtn.onclick = function () {
      if (confirm("この履歴を削除しますか？")) {
        Storage.deleteSession(session.id);
        renderHistory();
      }
    };
    detailElem.appendChild(deleteBtn);
  }

  return {
    showScreen: showScreen,
    showLoading: showLoading,
    hideLoading: hideLoading,
    showError: showError,
    hideError: hideError,
    updateTopScreen: updateTopScreen,
    initSettingsScreen: initSettingsScreen,
    initSetupScreen: initSetupScreen,
    renderPracticeQuestion: renderPracticeQuestion,
    renderFeedback: renderFeedback,
    renderMockTurn: renderMockTurn,
    clearMockChat: clearMockChat,
    renderSummary: renderSummary,
    renderHistory: renderHistory
  };
})();
