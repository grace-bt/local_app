// gemini.js - Gemini APIクライアント (ブラウザ直接呼び出し、エラー分類、再試行、JSON検証)
const Gemini = (function () {

  // JSONテキストの抽出とクリーンアップ (Markdownコードブロック除去)
  function cleanJsonText(rawText) {
    if (!rawText) return "";
    let text = rawText.trim();
    // ```json ... ``` または ``` ... ``` を除去
    if (text.startsWith("```")) {
      const firstLineBreak = text.indexOf("\n");
      if (firstLineBreak !== -1) {
        text = text.substring(firstLineBreak + 1);
      }
      if (text.endsWith("```")) {
        text = text.substring(0, text.lastIndexOf("```"));
      }
      text = text.trim();
    }
    return text;
  }

  // エラーオブジェクトの生成
  function createError(kind, message, originalError, status) {
    return {
      kind: kind, // 'auth' | 'rate' | 'network' | 'timeout' | 'server' | 'blocked' | 'format'
      message: message,
      status: status || null,
      raw: originalError || null
    };
  }

  // 単一のgenerateContent呼び出し (fetch)
  async function _invokeApi(model, apiKey, promptText, temperature, task) {
    // --- テスト仕様書用モックモード分岐 (CONFIG.MOCK_MODE) ---
    if (CONFIG.MOCK_MODE) {
      const mode = CONFIG.MOCK_MODE;
      if (mode === "auth") {
        throw createError("auth", "APIキーが無効または権限がありません。(MOCK)", null, 401);
      } else if (mode === "rate") {
        throw createError("rate", "Gemini APIの無料枠レート制限(429)に達しました。(MOCK)", null, 429);
      } else if (mode === "network") {
        throw createError("network", "ネットワークエラーまたは通信制限が発生しました。(MOCK)");
      } else if (mode === "timeout") {
        throw createError("timeout", "リクエストがタイムアウトしました。(MOCK)");
      } else if (mode === "server") {
        throw createError("server", "Geminiサーバー側でエラーが発生しました(500)。(MOCK)", null, 500);
      } else if (mode === "blocked") {
        throw createError("blocked", "AIの応答がブロックされました理由: SAFETY(MOCK)");
      } else if (mode === "format") {
        return "{壊れた不正なJSONテキストです";
      } else if (mode === "missing_field") {
        return JSON.stringify({
          scores: { "結論": 4, "具体性": 3, "役割と成果": 4, "職種との関連": 4, "簡潔さ": 3 },
          good: ["具体的です"],
          improve: ["結論を先に述べましょう"]
          // exampleが意図的に欠落
        });
      } else if (mode === "invalid_score") {
        return JSON.stringify({
          scores: { "結論": 999, "具体性": "満点" },
          good: ["良い点"],
          improve: ["改善点"],
          example: "改善例"
        });
      } else if (mode === "xss") {
        return JSON.stringify({
          questions: [{ text: "<script>alert('xss')</script>AIに関する質問", category: "AI" }],
          text: "<img src=x onerror=alert('xss')>面接官の質問です",
          scores: { "結論": 5, "具体性": 4, "役割と成果": 4, "職種との関連": 4, "簡潔さ": 4 },
          good: ["<b onclick=alert(1)>太字タグ</b>"],
          improve: ["<svg onload=alert(1)>"],
          example: "<script>console.log('xss')</script>改善後の回答例",
          strengths: ["<script>強み</script>"],
          weaknesses: ["弱み"],
          nextThemes: ["テーマ"],
          overallAdvice: "<script>アドバイス</script>"
        });
      } else if (mode === "normal") {
        // 正常モック: task名で適切なJSONを返却
        if (task === "question") {
          return JSON.stringify({
            questions: [
              { text: "これまでのAI導入または業務改革プロジェクトでの具体的な役割と成果を教えてください。", category: "AI/業務改革" },
              { text: "技術的バックグラウンドがない関係者に対して、生成AIの制約をどのように説明しましたか？", category: "コミュニケーション" },
              { text: "課長・リーダーとしてチームの生産性を向上させた具体的な工夫は何ですか？", category: "マネジメント" }
            ]
          });
        } else if (task === "feedback") {
          return JSON.stringify({
            scores: { "結論": 4, "具体性": 4, "役割と成果": 3, "職種との関連": 5, "簡潔さ": 4 },
            good: ["結論が明確で、職種適合性が高い点", "業務改革の視点が具体的に語られている点"],
            improve: ["チーム内でのご自身の独自の役割をもう少し具体化すると説得力が増します"],
            example: "前職では [プロジェクト名] において、LLMを活用した自動化基盤を設計・導入しました。その結果、業務時間を [〇〇時間] 削減できました。"
          });
        } else if (task === "interviewer") {
          return JSON.stringify({
            text: "そのプロジェクトにおいて、最も困難だった課題と、それをどのように乗り越えたか具体的に教えていただけますか？",
            type: "followup",
            end: false
          });
        } else if (task === "summary") {
          return JSON.stringify({
            strengths: ["論理的で分かりやすい構成力", "AIおよび業務変革に対する深い理解"],
            weaknesses: ["具体的な数値による成果提示がやや控えめな点"],
            nextThemes: ["定量成果（削減率やROI）の明示", "リーダーシップ発揮エピソードの言語化"],
            overallAdvice: "全体として非常に説得力があり、即戦力としての活躍が期待できる回答でした。"
          });
        }
      }
    }

    const url = "https://generativelanguage.googleapis.com/v1beta/models/" + encodeURIComponent(model) + ":generateContent";

    const controller = new AbortController();
    const timeoutId = setTimeout(function () {
      controller.abort();
    }, CONFIG.REQUEST_TIMEOUT_MS);

    const requestBody = {
      contents: [
        {
          role: "user",
          parts: [{ text: promptText }]
        }
      ],
      generationConfig: {
        temperature: typeof temperature === "number" ? temperature : 0.7,
        responseMimeType: "application/json"
      }
    };

    let response;
    try {
      response = await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-goog-api-key": apiKey
        },
        body: JSON.stringify(requestBody),
        signal: controller.signal
      });
    } catch (err) {
      clearTimeout(timeoutId);
      if (err.name === "AbortError") {
        throw createError("timeout", "リクエストがタイムアウトしました(" + (CONFIG.REQUEST_TIMEOUT_MS / 1000) + "秒)。再試行してください。", err);
      }
      // CORSエラーやオフライン等
      throw createError("network", "ネットワークエラーまたは通信制限が発生しました。インターネット接続とfile://からの通信許可を確認してください。", err);
    }

    clearTimeout(timeoutId);

    // HTTPステータスチェック
    if (!response.ok) {
      let errBody = null;
      try {
        errBody = await response.json();
      } catch (e) {
        // ignore
      }

      const status = response.status;
      const errMsg = (errBody && errBody.error && errBody.error.message) ? errBody.error.message : response.statusText;

      if (status === 400 || status === 401 || status === 403) {
        throw createError("auth", "APIキーが無効または権限がありません。キーを確認してください。(" + errMsg + ")", errBody, status);
      } else if (status === 429) {
        throw createError("rate", "Gemini APIの無料枠レート制限(429)に達しました。しばらく待ってから再試行してください。", errBody, status);
      } else if (status >= 500) {
        throw createError("server", "Geminiサーバー側でエラーが発生しました(" + status + ")。自動再試行または再送してください。", errBody, status);
      } else {
        throw createError("network", "APIリクエスト失敗(" + status + "): " + errMsg, errBody, status);
      }
    }

    let data;
    try {
      data = await response.json();
    } catch (err) {
      throw createError("format", "APIの応答がJSON形式ではありませんでした。", err);
    }

    // 安全性ブロック等のチェック
    const candidate = data.candidates && data.candidates[0];
    if (!candidate) {
      const blockReason = (data.promptFeedback && data.promptFeedback.blockReason) || "安全性フィルター";
      throw createError("blocked", "AIの応答がブロックされました理由: " + blockReason, data);
    }

    if (candidate.finishReason && candidate.finishReason !== "STOP") {
      if (candidate.finishReason === "SAFETY") {
        throw createError("blocked", "回答内容が安全性フィルターによりブロックされました。表現を調整してください。", candidate);
      }
    }

    const textPart = candidate.content && candidate.content.parts && candidate.content.parts[0];
    if (!textPart || typeof textPart.text !== "string") {
      throw createError("format", "API応答にテキストが含まれていませんでした。", candidate);
    }

    return textPart.text;
  }

  // JSONスキーマ検証ヘルパー
  function validateJson(parsed, task) {
    if (!parsed || typeof parsed !== "object") return false;

    switch (task) {
      case "question":
        return Array.isArray(parsed.questions) && parsed.questions.length > 0 && typeof parsed.questions[0].text === "string";
      case "feedback":
        return typeof parsed.scores === "object" && Array.isArray(parsed.good) && Array.isArray(parsed.improve) && typeof parsed.example === "string";
      case "interviewer":
        return typeof parsed.text === "string" && parsed.text.trim().length > 0;
      case "summary":
        return Array.isArray(parsed.strengths) && Array.isArray(parsed.weaknesses) && Array.isArray(parsed.nextThemes);
      default:
        return true;
    }
  }

  // callJson: プロンプトとタスクを受け取り、JSONとして解析・検証して返す (失敗時1回自動再試行)
  async function callJson(task, promptText, temperature) {
    const settings = Storage.getSettings();
    const apiKey = settings.apiKey;
    const model = settings.model || CONFIG.DEFAULT_MODEL;

    if (!apiKey) {
      throw createError("auth", "Gemini APIキーが設定されていません。右上の「設定」からキーを登録してください。");
    }

    let lastError = null;

    // 最大2回試行 (初回 + 失敗時の自動再試行1回)
    for (let attempt = 1; attempt <= 2; attempt++) {
      try {
        const rawText = await _invokeApi(model, apiKey, promptText, temperature, task);
        const cleaned = cleanJsonText(rawText);

        let parsed;
        try {
          parsed = JSON.parse(cleaned);
        } catch (jsonErr) {
          // JSONパース失敗時、もし2回目なら生テキストを救済格納
          if (attempt === 2) {
            console.warn("JSON parse failed twice, returning fallback object with raw text:", rawText);
            return {
              _isRawFallback: true,
              rawText: rawText,
              text: rawText,
              questions: [{ text: rawText, category: "一般" }],
              scores: { "結論": 3, "具体性": 3, "役割と成果": 3, "職種との関連": 3, "簡潔さ": 3 },
              good: ["AIがテキストで回答しました（JSON整形失敗）"],
              improve: ["モデルの応答形式が乱れました。再試行を推奨します。"],
              example: rawText,
              strengths: [rawText],
              weaknesses: [],
              nextThemes: []
            };
          }
          throw createError("format", "AIの応答をJSONとして解析できませんでした。", jsonErr);
        }

        // スキーマ検証
        if (!validateJson(parsed, task)) {
          if (attempt === 2) {
            console.warn("JSON schema validation failed twice, returning parsed object anyway:", parsed);
            return parsed;
          }
          throw createError("format", "AI応答の必須項目が不足していました。", parsed);
        }

        return parsed;

      } catch (err) {
        lastError = err;
        // 再試行対象: format(JSON不正)またはserver(5xx)エラーのみ
        if (attempt === 1 && (err.kind === "format" || err.kind === "server")) {
          console.warn("Attempt 1 failed with " + err.kind + ", retrying once...", err);
          continue;
        }
        // rate, auth, timeout, network, blocked は自動再試行せず即時スロー
        throw err;
      }
    }

    throw lastError;
  }

  // 接続テスト用 (S2用)
  async function testConnection(apiKey, model) {
    if (!apiKey) {
      throw createError("auth", "APIキーを入力してください。");
    }
    const targetModel = model || CONFIG.DEFAULT_MODEL;
    const testPrompt = "こんにちは。これは面接練習アプリの接続テストです。{\"status\": \"ok\", \"message\": \"接続成功\"} というJSONのみを返してください。";

    const rawText = await _invokeApi(targetModel, apiKey, testPrompt, 0.1);
    const cleaned = cleanJsonText(rawText);
    try {
      const parsed = JSON.parse(cleaned);
      return { success: true, model: targetModel, message: parsed.message || "接続に成功しました。" };
    } catch (e) {
      return { success: true, model: targetModel, message: "接続成功 (テキスト応答確認)" };
    }
  }

  return {
    callJson: callJson,
    testConnection: testConnection
  };
})();
