// config.js - アプリ共通設定・定数
const CONFIG = {
  // デフォルトモデル (Gemini無料枠で広く使える安定モデル)
  DEFAULT_MODEL: "gemini-2.5-flash",
  // 選択可能モデル候補
  AVAILABLE_MODELS: [
    { id: "gemini-2.5-flash", name: "Gemini 2.5 Flash (推奨・高速)" },
    { id: "gemini-2.5-pro", name: "Gemini 2.5 Pro (高品質)" },
    { id: "gemini-1.5-flash", name: "Gemini 1.5 Flash (旧安定版)" }
  ],
  // 1回の模擬面接での標準問数
  DEFAULT_QUESTION_COUNT: 5,
  MAX_QUESTION_COUNT: 10,
  MIN_QUESTION_COUNT: 1,

  // 1問あたりの深掘り質問の最大回数
  MAX_FOLLOWUPS_PER_QUESTION: 2,

  // APIタイムアウト(ミリ秒)
  REQUEST_TIMEOUT_MS: 45000,

  // 直近質問の重複回避保持件数
  RECENT_QUESTIONS_LIMIT: 50,

  // 履歴保存の最大件数
  MAX_SESSIONS_SAVED: 200,

  // 評価観点（F4）
  EVALUATION_CRITERIA: [
    { key: "結論", label: "結論ファースト", desc: "最初に結論・主張が述べられているか" },
    { key: "具体性", label: "具体性", desc: "数字、事例、状況説明が具体的か" },
    { key: "役割と成果", label: "役割と成果", desc: "自分の具体的なアクションと生み出した結果が明確か" },
    { key: "職種との関連", label: "職種適合性", desc: "志望職種で求められる能力や経験に合致しているか" },
    { key: "簡潔さ", label: "簡潔さ", desc: "冗長にならず分かりやすくまとまっているか" }
  ],

  // テスト用モックモード設定 (テスト仕様書 2章・10章: 通信失敗・制限超過・壊れたJSON等の検証用)
  // null: 通常通信, "rate": 429制限, "auth": 認証エラー, "network": 通信エラー, "timeout": タイムアウト,
  // "server": 5xxエラー, "blocked": 安全性ブロック, "format": 不正JSON, "missing_field": 改善例欠落, "invalid_score": 不正スコア, "xss": XSSタグ入り, "normal": 正常モック
  MOCK_MODE: null
};
