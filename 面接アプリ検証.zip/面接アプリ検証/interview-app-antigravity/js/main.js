// main.js - アプリ起動処理とイベントリスナーの登録
document.addEventListener("DOMContentLoaded", function () {

  // --- ナビゲーション・共通ボタン ---
  document.querySelectorAll(".nav-to-top").forEach(function (btn) {
    btn.addEventListener("click", function () {
      UI.showScreen("top");
      UI.updateTopScreen();
    });
  });

  document.getElementById("btn-go-settings").addEventListener("click", function () {
    UI.initSettingsScreen();
    UI.showScreen("settings");
  });

  document.getElementById("btn-go-history").addEventListener("click", function () {
    UI.renderHistory();
    UI.showScreen("history");
  });

  // S1 トップ画面からの遷移
  document.getElementById("btn-start-practice").addEventListener("click", function () {
    UI.initSetupScreen("practice");
    UI.showScreen("setup");
  });

  document.getElementById("btn-start-mock").addEventListener("click", function () {
    UI.initSetupScreen("mock");
    UI.showScreen("setup");
  });

  // --- S2 設定画面イベント ---
  const keyInput = document.getElementById("setting-api-key");
  const modelSelect = document.getElementById("setting-model");
  const countInput = document.getElementById("setting-question-count");
  const testBtn = document.getElementById("btn-test-connection");
  const saveBtn = document.getElementById("btn-save-settings");
  const clearKeyBtn = document.getElementById("btn-clear-key");
  const statusMsg = document.getElementById("setting-status-msg");

  // 接続テスト
  testBtn.addEventListener("click", async function () {
    statusMsg.className = "status-text";
    let keyToTest = keyInput.value.trim();
    if (keyToTest === "********") {
      keyToTest = Storage.getSettings().apiKey;
    }

    if (!keyToTest) {
      statusMsg.className = "status-text error";
      statusMsg.textContent = "APIキーを入力してください。";
      return;
    }

    UI.showLoading("Gemini APIへ接続テスト中...");
    try {
      const res = await Gemini.testConnection(keyToTest, modelSelect.value);
      UI.hideLoading();
      statusMsg.className = "status-text success";
      statusMsg.textContent = "✓ " + res.message + " (" + res.model + ")";
    } catch (err) {
      UI.hideLoading();
      statusMsg.className = "status-text error";
      statusMsg.textContent = "✗ 接続失敗: " + err.message;
    }
  });

  // 設定保存
  saveBtn.addEventListener("click", function () {
    let keyVal = keyInput.value.trim();
    const current = Storage.getSettings();
    if (keyVal === "********") {
      keyVal = current.apiKey;
    }

    const newSettings = {
      apiKey: keyVal,
      model: modelSelect.value,
      questionCount: parseInt(countInput.value, 10) || CONFIG.DEFAULT_QUESTION_COUNT
    };

    Storage.saveSettings(newSettings);

    // プロフィール保存 (F7)
    const profile = {
      summary: (document.getElementById("setting-profile-summary").value || "").trim(),
      strengths: (document.getElementById("setting-profile-strengths").value || "").trim(),
      aiBackground: (document.getElementById("setting-profile-ai").value || "").trim()
    };
    Storage.saveProfile(profile);

    statusMsg.className = "status-text success";
    statusMsg.textContent = "設定を保存しました。";
    UI.updateTopScreen();
  });

  // キー削除
  clearKeyBtn.addEventListener("click", function () {
    if (confirm("保存されているAPIキーを削除しますか？")) {
      Storage.clearApiKey();
      keyInput.value = "";
      statusMsg.className = "status-text";
      statusMsg.textContent = "APIキーを削除しました。";
      UI.updateTopScreen();
    }
  });

  // データエクスポート (キーを含まないJSON)
  document.getElementById("btn-export-data").addEventListener("click", function () {
    const jsonStr = Storage.exportAll();
    const blob = new Blob([jsonStr], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    const dateStr = new Date().toISOString().slice(0, 10);
    a.href = url;
    a.download = "interview_prep_backup_" + dateStr + ".json";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  });

  // データインポート
  document.getElementById("file-import-data").addEventListener("change", function (e) {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = function (event) {
      const res = Storage.importAll(event.target.result);
      if (res.success) {
        alert("データを正常に復元しました。");
        UI.initSettingsScreen();
        UI.updateTopScreen();
      } else {
        alert("インポート失敗: " + res.error);
      }
    };
    reader.readAsText(file);
    e.target.value = "";
  });

  // 全履歴消去
  document.getElementById("btn-clear-all-data").addEventListener("click", function () {
    if (confirm("全履歴・設定を完全に消去しますか？\n（エクスポートによるバックアップを推奨します）")) {
      Storage.clearAllData();
      alert("すべてのデータを消去しました。");
      UI.initSettingsScreen();
      UI.updateTopScreen();
      UI.showScreen("top");
    }
  });

  // --- S3 練習設定画面イベント ---
  const setupJobSelect = document.getElementById("setup-job-select");
  const customJobInput = document.getElementById("setup-custom-job");

  setupJobSelect.addEventListener("change", function () {
    if (setupJobSelect.value === "__custom__") {
      customJobInput.classList.remove("hidden");
      customJobInput.focus();
    } else {
      customJobInput.classList.add("hidden");
    }
  });

  // 練習・模擬面接 開始ボタン
  document.getElementById("btn-start-session").addEventListener("click", async function () {
    let selectedJob = setupJobSelect.value;
    if (selectedJob === "__custom__") {
      selectedJob = customJobInput.value.trim();
    }
    if (!selectedJob) {
      alert("職種を選択または入力してください。");
      return;
    }

    const stageId = document.getElementById("setup-stage-select").value;
    const categoryId = document.getElementById("setup-category-select").value;
    const mockCount = parseInt(document.getElementById("setup-mock-count").value, 10) || CONFIG.DEFAULT_QUESTION_COUNT;

    // 前回の選択を記憶
    Storage.saveSettings({ lastJob: selectedJob, lastStage: stageId });

    if (document.getElementById("setup-mode-title").textContent.includes("質問練習")) {
      // 質問練習開始
      UI.showLoading("職種と面接段階に合わせてAIが質問を生成中...");
      try {
        const data = await Practice.startPractice({
          job: selectedJob,
          stageId: stageId,
          categoryId: categoryId,
          questionCount: 3 // 練習モードは3問ずつ
        });
        UI.hideLoading();
        UI.renderPracticeQuestion(data);
        UI.showScreen("practice");
      } catch (err) {
        UI.hideLoading();
        UI.showError(err, function () {
          document.getElementById("btn-start-session").click();
        });
      }
    } else {
      // 模擬面接開始
      UI.showLoading("面接官が準備しています...");
      UI.clearMockChat();
      try {
        const data = await Mock.startMock({
          job: selectedJob,
          stageId: stageId,
          questionCount: mockCount
        });
        UI.hideLoading();
        UI.renderMockTurn(data.turn, data.progress);
        UI.showScreen("mock");
      } catch (err) {
        UI.hideLoading();
        UI.showError(err, function () {
          document.getElementById("btn-start-session").click();
        });
      }
    }
  });

  // --- S4 質問練習画面イベント ---
  const practiceAnswerInput = document.getElementById("practice-answer-input");
  const practiceCharCount = document.getElementById("practice-char-count");

  practiceAnswerInput.addEventListener("input", function () {
    practiceCharCount.textContent = practiceAnswerInput.value.length + " 文字";
  });

  // 回答送信 (F4)
  document.getElementById("btn-submit-practice-answer").addEventListener("click", async function () {
    const text = practiceAnswerInput.value.trim();
    if (!text) {
      alert("回答を入力してください。");
      return;
    }

    UI.showLoading("AIが評価基準に基づいて回答を添削中...");
    try {
      const result = await Practice.submitAnswer(text);
      UI.hideLoading();
      UI.renderFeedback(result);
      UI.showScreen("feedback");
    } catch (err) {
      UI.hideLoading();
      // 入力内容は保持したままエラー表示
      UI.showError(err, function () {
        document.getElementById("btn-submit-practice-answer").click();
      });
    }
  });

  // 質問スキップ
  document.getElementById("btn-skip-practice").addEventListener("click", function () {
    const next = Practice.nextQuestion();
    if (next.hasNext) {
      UI.renderPracticeQuestion(next);
    } else {
      alert("すべての質問が終了しました。トップに戻ります。");
      UI.showScreen("top");
      UI.updateTopScreen();
    }
  });

  // --- S5 フィードバック画面イベント ---
  // 再回答ボタン (同じ質問で修正して答える)
  document.getElementById("fb-btn-retry").addEventListener("click", function () {
    const qData = Practice.retryCurrentAnswer();
    practiceAnswerInput.value = "";
    practiceCharCount.textContent = "0 文字";
    UI.showScreen("practice");
  });

  // 次の質問 / 終了ボタン
  document.getElementById("fb-btn-next").addEventListener("click", function () {
    const next = Practice.nextQuestion();
    if (next.hasNext) {
      UI.renderPracticeQuestion(next);
      UI.showScreen("practice");
    } else {
      UI.showScreen("top");
      UI.updateTopScreen();
    }
  });

  // --- S6 模擬面接画面イベント ---
  const mockInput = document.getElementById("mock-answer-input");
  const mockSendBtn = document.getElementById("mock-send-btn");

  mockSendBtn.addEventListener("click", async function () {
    const answer = mockInput.value.trim();
    if (!answer) {
      alert("回答を入力してください。");
      return;
    }

    // まず候補者の発言を画面に即時反映
    UI.renderMockTurn({ role: "candidate", text: answer }, Mock.getProgress());
    mockSendBtn.disabled = true;

    UI.showLoading("面接官が回答を検討中...");
    try {
      const nextTurn = await Mock.sendAnswer(answer);
      UI.hideLoading();
      if (nextTurn.finished) {
        // 面接終了 -> 総評表示
        UI.renderSummary(nextTurn.summary, nextTurn.session || Mock.getSession());
        UI.showScreen("summary");
      } else {
        // 次の質問・深掘り表示
        UI.renderMockTurn(nextTurn.turn, nextTurn.progress);
      }
    } catch (err) {
      UI.hideLoading();
      mockSendBtn.disabled = false;
      UI.showError(err, function () {
        mockSendBtn.click();
      });
    }
  });

  // 模擬面接の途中終了
  document.getElementById("mock-finish-early-btn").addEventListener("click", async function () {
    if (confirm("模擬面接をここで終了し、ここまでの回答で総評を作成しますか？")) {
      UI.showLoading("これまでの回答をもとに総評を作成中...");
      try {
        const result = await Mock.finishMock();
        UI.hideLoading();
        UI.renderSummary(result.summary, Mock.getSession());
        UI.showScreen("summary");
      } catch (err) {
        UI.hideLoading();
        UI.showError(err);
      }
    }
  });

  // --- 初期表示処理 ---
  UI.updateTopScreen();
  UI.showScreen("top");
});
