// practice.js - 質問練習モード(F4 / S4, S5)の進行ロジック
const Practice = (function () {
  let currentSession = null;
  let currentQuestion = null;
  let currentQuestionIndex = 0;
  let questionList = [];

  function generateSessionId() {
    const d = new Date();
    const pad = function (n) { return n < 10 ? "0" + n : "" + n; };
    return "s_prac_" + d.getFullYear() + pad(d.getMonth() + 1) + pad(d.getDate()) + "_" +
      pad(d.getHours()) + pad(d.getMinutes()) + pad(d.getSeconds());
  }

  // 練習セッションの開始（質問生成）
  async function startPractice(options) {
    const job = options.job;
    const stageId = options.stageId;
    const stageObj = PRESETS.stages.find(function (s) { return s.id === stageId; });
    const stageName = stageObj ? stageObj.name : "一次面接";
    const categoryId = options.categoryId;
    const catObj = PRESETS.categories.find(function (c) { return c.id === categoryId; });
    const categoryName = catObj ? catObj.name : "総合質問";
    const questionCount = options.questionCount || 1;

    const recent = Storage.getRecentQuestionsForJob(job);
    const profile = Storage.getProfile();

    const prompt = Prompts.buildQuestionPrompt({
      job: job,
      stageName: stageName,
      categoryName: categoryName,
      count: questionCount,
      recentQuestions: recent,
      profile: profile
    });

    const result = await Gemini.callJson("question", prompt, 0.7);
    const questions = result.questions || [];

    if (questions.length === 0) {
      throw { kind: "format", message: "質問が生成されませんでした。もう一度試してください。" };
    }

    // 重複回避リストに登録
    Storage.addQuestions(questions, job);

    questionList = questions;
    currentQuestionIndex = 0;
    currentQuestion = questions[0];

    // 新規セッションの作成
    currentSession = {
      id: generateSessionId(),
      mode: "practice",
      job: job,
      stage: stageName,
      startedAt: new Date().toISOString(),
      turns: [
        {
          role: "interviewer",
          text: currentQuestion.text,
          category: currentQuestion.category || categoryName
        }
      ],
      summary: null
    };

    Storage.addSession(currentSession);

    return {
      session: currentSession,
      question: currentQuestion,
      index: currentQuestionIndex + 1,
      total: questionList.length
    };
  }

  // 回答の送信とフィードバック取得 (F4)
  async function submitAnswer(answerText) {
    if (!currentSession || !currentQuestion) {
      throw { kind: "system", message: "練習セッションが見つかりません。" };
    }

    const trimmed = (answerText || "").trim();
    if (!trimmed) {
      throw { kind: "validation", message: "回答を入力してください。" };
    }

    const profile = Storage.getProfile();
    const prompt = Prompts.buildFeedbackPrompt({
      job: currentSession.job,
      question: currentQuestion.text,
      answer: trimmed,
      profile: profile
    });

    // 採点フィードバックは低めの温度でブレを抑える
    const feedback = await Gemini.callJson("feedback", prompt, 0.3);

    // 候補者ターンとフィードバックをセッションに追加
    currentSession.turns.push({
      role: "candidate",
      text: trimmed,
      feedback: {
        scores: feedback.scores || {},
        good: feedback.good || [],
        improve: feedback.improve || [],
        example: feedback.example || ""
      }
    });

    Storage.updateSession(currentSession);

    return {
      question: currentQuestion.text,
      answer: trimmed,
      feedback: feedback,
      hasNext: (currentQuestionIndex + 1) < questionList.length
    };
  }

  // 再回答のための準備 (同じ質問で再度答える)
  function retryCurrentAnswer() {
    return {
      question: currentQuestion ? currentQuestion.text : "",
      previousAnswer: ""
    };
  }

  // 次の質問へ進む
  function nextQuestion() {
    currentQuestionIndex++;
    if (currentQuestionIndex < questionList.length) {
      currentQuestion = questionList[currentQuestionIndex];
      // セッションに次の質問ターンを追加
      currentSession.turns.push({
        role: "interviewer",
        text: currentQuestion.text,
        category: currentQuestion.category
      });
      Storage.updateSession(currentSession);
      return {
        hasNext: true,
        question: currentQuestion,
        index: currentQuestionIndex + 1,
        total: questionList.length
      };
    } else {
      return {
        hasNext: false
      };
    }
  }

  function getCurrentSession() {
    return currentSession;
  }

  return {
    startPractice: startPractice,
    submitAnswer: submitAnswer,
    retryCurrentAnswer: retryCurrentAnswer,
    nextQuestion: nextQuestion,
    getCurrentSession: getCurrentSession
  };
})();
