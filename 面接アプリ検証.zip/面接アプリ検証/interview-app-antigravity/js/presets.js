// presets.js - 職種・面接段階・質問カテゴリのプリセット定義
const PRESETS = {
  // 職種プリセット (IT関係 + AI関連職を手厚く)
  jobs: [
    {
      id: "ai_product_engineer",
      name: "AIプロダクトエンジニア",
      category: "ai",
      description: "LLMアプリ開発、プロンプト設計、RAG構築、AI機能の実装と運用",
      focusAreas: ["LLMアプリ開発経験", "プロンプトエンジニアリング・評価", "AIモデル選定とレイテンシ最適化", "PoCから本番化への推進力"]
    },
    {
      id: "ai_solution_consultant",
      name: "AI導入支援・コンサルタント",
      category: "ai",
      description: "生成AI活用による業務改革、PoC企画推進、クライアント伴走支援",
      focusAreas: ["業務改革・プロセス再設計", "非技術層へのAI価値伝達", "ROI・導入対効果の説明", "プロジェクト推進・チェンジマネジメント"]
    },
    {
      id: "web_frontend_engineer",
      name: "フロントエンドエンジニア",
      category: "it",
      description: "React/Next.js/TypeScript等を用いたWeb UI設計・開発・パフォーマンス改善",
      focusAreas: ["UI/UX設計とアクセシビリティ", "コンポーネント設計・状態管理", "Webパフォーマンス改善", "チーム開発とコード品質"]
    },
    {
      id: "web_backend_engineer",
      name: "バックエンドエンジニア",
      category: "it",
      description: "API設計、データベース設計、マイクロサービス開発、負荷対策",
      focusAreas: ["API・DB設計とスケーラビリティ", "障害対応・信頼性設計", "セキュリティ対応", "業務要件の技術への落とし込み"]
    },
    {
      id: "cloud_infra_engineer",
      name: "クラウド・インフラエンジニア (SRE)",
      category: "it",
      description: "AWS/GCP環境構築、IaC、CI/CD、モニタリング・SLO運用",
      focusAreas: ["インフラ自動化(IaC/CI/CD)", "可観測性(Observability)と障害対応", "コスト最適化", "セキュリティガバナンス"]
    },
    {
      id: "it_pdm_pm",
      name: "プロダクトマネージャー / プロジェクトマネージャー",
      category: "it",
      description: "プロダクト要件定義、ロードマップ策定、ステークホルダー調整、進捗管理",
      focusAreas: ["課題定義と優先順位付け", "ステークホルダー合意形成", "開発チームとの協働", "成果創出と指標管理"]
    },
    {
      id: "engineering_manager",
      name: "エンジニアリングマネージャー / リードエンジニア",
      category: "management",
      description: "チームビルディング、ピープルマネジメント、技術戦略策定、組織課題解決",
      focusAreas: ["チームの生産性向上", "ピープルマネジメント・育成", "技術的意思決定と経営層への説明", "課長・リーダーとしての組織貢献"]
    }
  ],

  // 面接段階
  stages: [
    { id: "casual", name: "カジュアル面談", desc: "カルチャーマッチ、これまでの大まかな経歴、今後のキャリア志向の確認" },
    { id: "first", name: "一次面接 (現場/リーダー)", desc: "実務能力、技術的知見、具体的な経験・スキルの深掘り確認" },
    { id: "second", name: "二次面接 (部長・マネージャー)", desc: "課題解決力、周囲との協調・リード力、業務改革への取り組み" },
    { id: "final", name: "最終面接 (役員/社長)", desc: "志望動機の強さ、企業理念への共感、入社後のキャリアビジョン、覚悟" }
  ],

  // 質問カテゴリ
  categories: [
    { id: "self_intro", name: "自己紹介・経歴概括" },
    { id: "motivation", name: "志望動機・キャリア転換" },
    { id: "behavioral", name: "行動面接・成功/失敗体験" },
    { id: "tech_ai", name: "技術知見・AI/業務改革" },
    { id: "leadership", name: "リーダーシップ・課長/協調経験" },
    { id: "reverse", name: "逆質問・意欲確認" }
  ]
};
