(function(){'use strict';document.addEventListener('DOMContentLoaded',()=>{try{AppUI.init()}catch(e){console.error('アプリ起動エラー',e)}})})();
