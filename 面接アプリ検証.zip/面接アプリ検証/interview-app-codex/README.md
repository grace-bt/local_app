# 面接ノート

転職面接の回答練習と模擬面接を行う、ローカル動作の日本語Webアプリです。HTML・CSS・JavaScriptのみで構成しており、ビルド環境やPython、Node.jsは不要です。

## 起動

1. `index.html` をWindowsの最新版Microsoft EdgeまたはGoogle Chromeで開きます。
2. 「設定」からGoogle AI Studioで作成したGemini APIキーを登録し、接続テストを行います。
3. ホームから「質問に答える」または「模擬面接をする」を選びます。

アプリはブラウザからGemini APIへ直接通信します。APIキーは利用者自身のブラウザで使われ、アプリ運営者のサーバーへ送信されません。APIキーの管理、モデルの利用条件、無料枠はGoogle AI StudioとGemini APIの公式情報を確認してください。

## プライバシーとデータ

- APIキー、設定、練習履歴、生成済み質問はブラウザの `localStorage` に保存されます。アカウントやアプリ側サーバーはありません。
- 入力した内容はGoogleのGemini APIに送信されます。無料枠では入力内容がサービス改善に利用される場合があるため、社名・個人情報・社外秘は入力しないでください。詳細は[公式の規約](https://ai.google.dev/gemini-api/terms)を確認してください。
- ブラウザデータを消去すると履歴やキーも消えます。設定画面から履歴をJSONでエクスポートし、安全な場所へ保管してください。エクスポートにはAPIキーは含まれません。
- AIの評価スコアは練習の目安で、合否を判定するものではありません。改善例に事実と異なる内容がないか、必ず確認してください。
- 共有PCでは練習後に設定画面からキーと履歴を削除してください。

## 画面・機能

- 職種、面接段階、質問数を指定した質問生成
- 5つの観点による回答フィードバックと改善例
- 深掘りを含む対話型の模擬面接と総評
- ブラウザ内の練習履歴、JSONエクスポート・インポート
- Gemini APIキーとモデル名の設定

## 動作上の注意

このアプリは `index.html` を直接開く `file://` 起動を想定しています。ただし、ブラウザやネットワークの設定によっては、`file://` ページから外部APIへの通信がCORS制限で拒否されることがあります。その場合、接続テストのエラーを確認してください。ブラウザのセキュリティ設定を弱める起動方法は推奨しません。

`file://` でのlocalStorageの扱いはブラウザの実装に依存し、ファイルの移動や名前変更後に同じ保存領域を参照できる保証はありません。重要な履歴は定期的にエクスポートしてください。

APIの無料枠、モデル名、レート制限、利用可能な構造化出力機能は変更される場合があります。初期モデルは `gemini-2.5-flash-lite` です。接続できない場合は、設定画面で現在利用可能なモデル名に変更してください。

## Google公式情報

- [Gemini API クイックスタート・REST](https://ai.google.dev/gemini-api/docs/quickstart)
- [Gemini API モデル一覧](https://ai.google.dev/gemini-api/docs/models)
- [Gemini API レート制限](https://ai.google.dev/gemini-api/docs/rate-limits)
- [Gemini API 料金と無料枠](https://ai.google.dev/gemini-api/docs/pricing)
- [Gemini API 利用規約](https://ai.google.dev/gemini-api/terms)
