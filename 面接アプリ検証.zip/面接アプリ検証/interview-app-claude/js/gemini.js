// Gemini API呼び出し。HTTP・再試行・JSON検証はここだけで扱う
// ※エンドポイント・ヘッダー・JSON出力の仕様は Google公式ドキュメントで要確認(設計書 第13章)
(function () {
  var busy = false;

  function GeminiError(kind, message, extra) {
    var e = new Error(message);
    e.kind = kind;
    if (extra) Object.assign(e, extra);
    return e;
  }

  function parseRetryAfter(body) {
    try {
      var details = body && body.error && body.error.details || [];
      for (var i = 0; i < details.length; i++) {
        if (details[i].retryDelay) return Math.ceil(parseFloat(details[i].retryDelay));
      }
      var m = /retry in ([\d.]+)s/i.exec((body.error && body.error.message) || '');
      if (m) return Math.ceil(parseFloat(m[1]));
    } catch (e) { /* noop */ }
    return null;
  }

  function stripFence(t) {
    t = t.trim();
    t = t.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
    if (t[0] !== '{' && t[0] !== '[') {
      var a = t.indexOf('{'), b = t.lastIndexOf('}');
      if (a >= 0 && b > a) t = t.slice(a, b + 1);
    }
    return t;
  }

  // 1回のHTTP呼び出し。テキストを返す
  async function request(prompt, task, opts) {
    var s = AppStore.getSettings();
    var key = opts.key || s.apiKey;
    var model = opts.model || s.model || CONFIG.defaultModel;
    if (!key) throw GeminiError('auth', 'APIキーが設定されていません。');

    var gen = { temperature: task.temperature };
    if (!opts.noSchema) {
      gen.responseMimeType = 'application/json';
      gen.responseSchema = task.schema;
    }
    var body = { contents: [{ role: 'user', parts: [{ text: prompt }] }], generationConfig: gen };

    var ctrl = new AbortController();
    var timer = setTimeout(function () { ctrl.abort(); }, CONFIG.timeoutMs);
    var res;
    try {
      res = await fetch(CONFIG.apiBase + encodeURIComponent(model) + ':generateContent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-goog-api-key': key },
        body: JSON.stringify(body),
        signal: ctrl.signal
      });
    } catch (e) {
      if (e && e.name === 'AbortError') throw GeminiError('timeout', '応答がタイムアウトしました。');
      throw GeminiError('network', '通信できませんでした。ネットワーク接続を確認してください。');
    } finally {
      clearTimeout(timer);
    }

    var json = null;
    try { json = await res.json(); } catch (e) { /* noop */ }
    var apiMsg = json && json.error && json.error.message || '';

    if (!res.ok) {
      var st = res.status;
      if (st === 429) throw GeminiError('rate', '無料枠の制限に達しました。', { retryAfter: parseRetryAfter(json) });
      if (st === 401 || st === 403 || /API key/i.test(apiMsg)) throw GeminiError('auth', 'APIキーを確認してください。', { detail: apiMsg });
      if (st >= 500) throw GeminiError('server', 'Gemini側でエラーが発生しました(' + st + ')。', { detail: apiMsg });
      if (st === 400 && !opts.noSchema && /schema|response_mime|mime|json mode|responseSchema/i.test(apiMsg)) {
        throw GeminiError('schema', apiMsg);
      }
      throw GeminiError('request', 'リクエストが受け付けられませんでした(' + st + ')。モデル名などを確認してください。', { detail: apiMsg });
    }

    var cand = json && json.candidates && json.candidates[0];
    var text = cand && cand.content && cand.content.parts
      ? cand.content.parts.map(function (p) { return p.text || ''; }).join('') : '';
    if (!text.trim()) {
      var reason = (json && json.promptFeedback && json.promptFeedback.blockReason) || (cand && cand.finishReason) || '';
      throw GeminiError('blocked', '応答が得られませんでした。' + (reason ? '(' + reason + ')' : ''));
    }
    return text;
  }

  var Gemini = {
    isBusy: function () { return busy; },

    // taskName: Prompts.tasks のキー。成功時は検証済みオブジェクトを返す
    callJson: async function (taskName, prompt, opts) {
      opts = Object.assign({}, opts);
      var task = Prompts.tasks[taskName];
      if (busy) throw GeminiError('busy', '別のリクエストを処理中です。');
      busy = true;
      try {
        var serverRetried = false, formatRetried = false, lastText = '';
        for (;;) {
          try {
            var text = await request(prompt, task, opts);
            lastText = text;
            var data = null;
            try { data = task.validate(JSON.parse(stripFence(text))); } catch (e) { data = null; }
            if (data) return data;
            if (!formatRetried) { formatRetried = true; continue; }
            throw GeminiError('format', 'AIの出力を解析できませんでした。', { raw: lastText });
          } catch (e) {
            if (e.kind === 'schema') { opts.noSchema = true; continue; }          // スキーマ非対応モデル: プロンプトのみで再試行
            if (e.kind === 'server' && !serverRetried) { serverRetried = true; continue; }
            throw e;
          }
        }
      } finally {
        busy = false;
      }
    },

    // 接続テスト。成功したら例外なし
    testKey: async function (key, model) {
      await Gemini.callJson('test', Prompts.buildTestPrompt(), { key: key, model: model });
      return true;
    }
  };
  window.Gemini = Gemini;
})();
