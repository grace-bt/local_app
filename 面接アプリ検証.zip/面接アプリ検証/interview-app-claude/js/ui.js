// 画面切り替えと描画。AIの出力は必ず textContent(h() 経由)で表示し、innerHTMLは使わない
(function () {
  var $ = function (id) { return document.getElementById(id); };

  function h(tag, props) {
    var e = document.createElement(tag);
    Object.keys(props || {}).forEach(function (k) {
      var v = props[k];
      if (v == null || v === false) return;
      if (k === 'class') e.className = v;
      else if (k.slice(0, 2) === 'on') e.addEventListener(k.slice(2), v);
      else e.setAttribute(k, v === true ? '' : v);
    });
    Array.prototype.slice.call(arguments, 2).forEach(function add(c) {
      if (c == null || c === false) return;
      if (Array.isArray(c)) c.forEach(add);
      else e.append(c instanceof Node ? c : document.createTextNode(String(c)));
    });
    return e;
  }
  function clear(el) { while (el.firstChild) el.removeChild(el.firstChild); }

  var screens = ['home', 'settings', 'setup', 'practice', 'feedback', 'mock', 'summary', 'history'];
  var mode = 'practice';        // setup画面の対象モード
  var P = null;                 // 質問練習の状態 {ctx, idx, last}
  var lastFeedbackAnswer = '';

  // ---------- 共通 ----------
  function showScreen(id) {
    screens.forEach(function (s) { $('screen-' + s).hidden = s !== id; });
    clearError();
    if (id === 'home') renderHome();
    if (id === 'settings') renderSettings();
    if (id === 'setup') renderSetup();
    if (id === 'history') renderHistory();
    window.scrollTo(0, 0);
  }
  function showLoading(msg) { $('loadingText').textContent = msg || 'AIが応答中…'; $('loading').hidden = false; }
  function hideLoading() { $('loading').hidden = true; }
  function clearError() { var b = $('errorBanner'); b.hidden = true; clear(b); }

  var ERR_TEXT = {
    auth: 'キーを確認してください。APIキーが無効、または権限がありません。',
    rate: '無料枠の制限に達しました。しばらく待ってから再試行してください。',
    network: '通信できませんでした。ネットワーク接続を確認して再試行してください。',
    timeout: '応答がタイムアウトしました。再送してください(問数やモデルの変更も検討してください)。',
    server: 'Gemini側でエラーが発生しました。再試行してください。',
    blocked: '応答が得られませんでした。回答を修正して再送してください。',
    format: 'AIの出力を解析できませんでした。',
    storage: '保存できませんでした。設定画面から履歴をエクスポートし、古い履歴を削除してください。',
    request: 'リクエストが受け付けられませんでした。モデル名などの設定を確認してください。',
    busy: '別のリクエストを処理中です。'
  };

  // retryFn があれば再試行ボタンを出す。入力中の回答は消さない
  function showError(err, retryFn) {
    var b = $('errorBanner');
    clear(b);
    var kind = err && err.kind || 'network';
    var msg = ERR_TEXT[kind] || (err && err.message) || '不明なエラーが発生しました。';
    if (kind === 'rate' && err.retryAfter) msg += '(目安: 約' + err.retryAfter + '秒後)';
    b.append(h('div', null, msg));
    if (err && err.detail && (kind === 'request' || kind === 'server')) b.append(h('div', { class: 'hint' }, err.detail));
    var row = h('div', { class: 'row' });
    if (kind === 'auth') row.append(h('button', { type: 'button', onclick: function () { showScreen('settings'); } }, '設定画面へ'));
    if (retryFn && kind !== 'auth' && kind !== 'storage') row.append(h('button', { type: 'button', onclick: function () { clearError(); retryFn(); } }, '再試行'));
    b.append(row);
    b.hidden = false;
    window.scrollTo(0, 0);
  }

  // AI呼び出しの共通ラッパー
  async function run(msg, fn, retryFn) {
    clearError(); // 前回のエラー表示を残さない
    showLoading(msg);
    try { return await fn(); }
    catch (e) { showError(e, retryFn); return undefined; }
    finally { hideLoading(); }
  }

  function counter(textarea, label) {
    function upd() { label.textContent = textarea.value.length + '文字 / 最大' + CONFIG.maxAnswerChars + '文字'; }
    textarea.setAttribute('maxlength', CONFIG.maxAnswerChars);
    textarea.addEventListener('input', upd);
    upd();
  }
  function fmtDate(iso) {
    var d = new Date(iso);
    return isNaN(d) ? iso : d.getFullYear() + '/' + (d.getMonth() + 1) + '/' + d.getDate() + ' ' +
      String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
  }
  function list(items) { return h('ul', { class: 'fb-list' }, items.map(function (t) { return h('li', null, t); })); }

  // ---------- S1 ----------
  function renderHome() {
    var has = AppStore.hasKey();
    document.querySelectorAll('[data-needkey]').forEach(function (b) { b.disabled = !has; });
    $('keyHint').hidden = has;
  }

  // ---------- S2 ----------
  function renderSettings() {
    var s = AppStore.getSettings();
    $('inpKey').value = '';
    $('inpKey').placeholder = s.apiKey ? '保存済み(' + '●'.repeat(8) + ')  変更する場合のみ入力' : '未設定';
    $('keyStatus').textContent = s.apiKey ? 'APIキー: 保存済み' : 'APIキー: 未設定';
    $('inpModel').value = s.model;
    $('inpCount').value = s.questionCount;
    $('inpCount').max = CONFIG.maxQuestionCount;
    $('pfJob').value = s.profile.job; $('pfCareer').value = s.profile.career;
    $('pfMotive').value = s.profile.motive; $('pfStrengths').value = s.profile.strengths;
    ['testResult', 'profileResult', 'dataResult'].forEach(function (i) { $(i).textContent = ''; });
  }
  function clampCount(v) { return Math.min(CONFIG.maxQuestionCount, Math.max(1, parseInt(v, 10) || CONFIG.defaultQuestionCount)); }

  function saveModelCount() {
    var model = $('inpModel').value.trim() || CONFIG.defaultModel;
    AppStore.saveSettings({ model: model, questionCount: clampCount($('inpCount').value) });
    return model;
  }

  async function testAndSaveKey() {
    var typed = $('inpKey').value.trim();
    var key = typed || AppStore.getSettings().apiKey;
    if (!key) { $('testResult').textContent = 'APIキーを入力してください。'; return; }
    var model = saveModelCount();
    $('testResult').textContent = '';
    var ok = await run('接続テスト中…', function () { return Gemini.testKey(key, model); }, testAndSaveKey);
    if (ok) {
      AppStore.saveSettings({ apiKey: key });
      $('inpKey').value = '';
      $('testResult').textContent = '接続に成功しました。キーを保存しました。';
      renderSettings();
      $('testResult').textContent = '接続に成功しました。キーを保存しました。';
    }
  }

  function bindSettings() {
    $('btnTestKey').onclick = testAndSaveKey;
    $('btnSaveSettings').onclick = function () {
      try { saveModelCount(); $('testResult').textContent = '保存しました。'; renderSettings(); $('testResult').textContent = '保存しました。'; }
      catch (e) { showError(e); }
    };
    $('btnDeleteKey').onclick = function () {
      if (!confirm('APIキーを削除しますか?')) return;
      AppStore.clearKey(); renderSettings(); $('testResult').textContent = 'キーを削除しました。';
    };
    $('btnSaveProfile').onclick = function () {
      try {
        AppStore.saveSettings({ profile: { job: $('pfJob').value.trim(), career: $('pfCareer').value.trim(), motive: $('pfMotive').value.trim(), strengths: $('pfStrengths').value.trim() } });
        $('profileResult').textContent = '保存しました。';
      } catch (e) { showError(e); }
    };
    $('btnExport').onclick = function () {
      var blob = new Blob([AppStore.exportAll()], { type: 'application/json' });
      var a = h('a', { href: URL.createObjectURL(blob), download: 'interview-app-export-' + new Date().toISOString().slice(0, 10) + '.json' });
      document.body.append(a); a.click(); a.remove();
      setTimeout(function () { URL.revokeObjectURL(a.href); }, 1000);
      $('dataResult').textContent = 'エクスポートしました(APIキーは含まれません)。';
    };
    $('btnImport').onclick = function () { $('fileImport').click(); };
    $('fileImport').onchange = function (ev) {
      var f = ev.target.files[0];
      if (!f) return;
      var r = new FileReader();
      r.onload = function () {
        try { $('dataResult').textContent = AppStore.importAll(String(r.result)) + '件の履歴を取り込みました。'; }
        catch (e) { $('dataResult').textContent = e.message; }
      };
      r.readAsText(f);
      ev.target.value = '';
    };
    $('btnClearAll').onclick = function () {
      if (!confirm('APIキー・設定・履歴・生成済み質問をすべて削除します。よろしいですか?')) return;
      AppStore.clearAll(); renderSettings(); $('dataResult').textContent = 'すべて削除しました。';
    };
  }

  // ---------- S3 ----------
  function renderSetup() {
    var s = AppStore.getSettings();
    $('setupTitle').textContent = mode === 'mock' ? '模擬面接の設定' : '質問練習の設定';
    var sel = $('selJob'); clear(sel);
    Presets.jobGroups.forEach(function (g) {
      sel.append(h('optgroup', { label: g.label }, g.jobs.map(function (j) { return h('option', { value: j }, j); })));
    });
    sel.append(h('option', { value: '__free' }, 'その他(自由入力)'));
    var known = Presets.jobGroups.some(function (g) { return g.jobs.indexOf(s.lastJob) >= 0; });
    if (s.lastJob && known) sel.value = s.lastJob;
    else if (s.lastJob) { sel.value = '__free'; $('inpJobFree').value = s.lastJob; }
    $('lblJobFree').hidden = sel.value !== '__free';
    var st = $('selStage'); clear(st);
    Presets.stages.forEach(function (x) { st.append(h('option', { value: x }, x)); });
    if (s.lastStage) st.value = s.lastStage;
    $('inpSetupCount').max = CONFIG.maxQuestionCount;
    $('inpSetupCount').value = s.questionCount;
    $('btnStart').disabled = false;
  }
  function selectedJob() {
    var v = $('selJob').value;
    return v === '__free' ? $('inpJobFree').value.trim() : v;
  }

  async function startFlow() {
    var job = selectedJob();
    if (!job) { showError({ kind: 'x', message: '職種を入力してください。' }); return; }
    var stage = $('selStage').value, count = clampCount($('inpSetupCount').value);
    $('btnStart').disabled = true;
    try {
      if (mode === 'mock') {
        bindMock();
        showScreen('mock'); clear($('chatLog')); $('mockAnswer').value = '';
        Mock.startMock(job, stage, count);
      } else {
        var ctx = await run('質問を生成中…', function () { return Practice.startPractice(job, stage, count); }, startFlow);
        if (ctx) { P = { ctx: ctx, idx: 0 }; showQuestion(); }
      }
    } finally { $('btnStart').disabled = false; }
  }

  // ---------- S4 / S5 ----------
  function showQuestion(prefill) {
    var q = P.ctx.questions[P.idx];
    showScreen('practice');
    $('practiceProgress').textContent = '第 ' + (P.idx + 1) + ' / ' + P.ctx.questions.length + ' 問  ・  ' + P.ctx.session.job + '(' + P.ctx.session.stage + ')';
    $('practiceCategory').textContent = q.category || '質問';
    $('practiceQuestion').textContent = q.text;
    $('practiceAnswer').value = prefill || '';
    $('practiceAnswer').dispatchEvent(new Event('input'));
    $('practiceAnswer').focus();
  }

  async function submitPractice() {
    var ans = $('practiceAnswer').value.trim();
    if (!ans) { showError({ kind: 'x', message: '回答を入力してください。' }); return; }
    var fb = await run('AIが添削中…', function () { return Practice.submitAnswer(P.ctx, P.idx, ans); }, submitPractice);
    if (fb) { lastFeedbackAnswer = ans; renderFeedback(fb); }
  }

  function renderFeedback(fb) {
    showScreen('feedback');
    var q = P.ctx.questions[P.idx], body = $('fbBody');
    $('fbQuestion').textContent = q.text;
    clear(body);
    if (fb.raw) {
      body.append(h('div', { class: 'card' }, h('h2', null, 'AIの出力(解析できなかったため生のテキストで表示)'), h('div', { class: 'example' }, fb.raw)));
    } else {
      body.append(h('div', { class: 'card' }, h('h2', null, '観点別スコア(目安)'),
        CONFIG.criteria.map(function (c) {
          var n = fb.scores[c];
          return h('div', { class: 'score-row' }, h('span', { class: 'score-label' }, c),
            h('div', { class: 'score-bar' }, h('span', { style: 'width:' + (n * 20) + '%' })), h('span', { class: 'score-num' }, n + '/5'));
        })));
      body.append(h('div', { class: 'card' }, h('h2', null, '良い点'), list(fb.good), h('h2', null, '改善点'), list(fb.improve)));
      body.append(h('div', { class: 'card' }, h('h2', null, '改善例'), h('div', { class: 'example' }, fb.example)));
    }
    var last = P.idx >= P.ctx.questions.length - 1;
    $('btnNextQuestion').textContent = last ? '終了して履歴へ' : '次の問へ';
  }

  function nextQuestion() {
    if (P.idx >= P.ctx.questions.length - 1) { showScreen('history'); return; }
    P.idx++; showQuestion();
  }

  // ---------- S6 模擬面接 ----------
  var mockBound = false;
  function bindMock() {
    if (mockBound) return;
    mockBound = true;
    Mock.onChange(renderMock);
  }

  function renderMock(M) {
    // 状態に合わせて読み込み表示・ボタンを切り替える
    var log = $('chatLog'); clear(log);
    M.session.turns.forEach(function (t) {
      log.append(h('div', { class: 'bubble ' + (t.role === 'interviewer' ? 'interviewer' : 'candidate') },
        h('span', { class: 'who' }, t.role === 'interviewer' ? '面接官' : 'あなた'), t.text));
    });
    $('mockProgress').textContent = M.session.job + '(' + M.session.stage + ')  ・  質問 ' + M.asked + ' / ' + M.total + '(残り ' + Math.max(0, M.total - M.asked) + '問)';
    var waiting = M.state === 'waiting';
    $('btnMockSend').disabled = !waiting;
    $('btnMockFinish').disabled = !waiting;
    $('mockAnswer').disabled = !waiting;
    if (M.state === 'asking') showLoading('面接官が考えています…');
    else if (M.state === 'summarizing') showLoading('総評を作成中…');
    else hideLoading();
    if (M.state === 'error') {
      showError(M.error, function () { Mock.retry(); });
    } else if (M.state === 'waiting') {
      clearError();
      $('mockAnswer').focus();
    } else if (M.state === 'done') {
      renderSummary(M.session);
      showScreen('summary');
      renderSummary(M.session);
    } else if (M.state === 'idle') {
      showScreen('home');
    }
    log.lastElementChild && log.lastElementChild.scrollIntoView({ block: 'nearest' });
  }

  function sendMock() {
    var t = $('mockAnswer').value.trim();
    if (!t) { showError({ kind: 'x', message: '回答を入力してください。' }); return; }
    $('mockAnswer').value = ''; $('mockAnswer').dispatchEvent(new Event('input'));
    Mock.sendAnswer(t);
  }

  // ---------- S7 ----------
  function renderSummary(session) {
    var body = $('summaryBody'); clear(body);
    var s = session.summary;
    if (!s) { body.append(h('p', null, '総評はありません。')); return; }
    if (s.raw) { body.append(h('div', { class: 'card' }, h('h2', null, 'AIの出力(解析できなかったため生のテキストで表示)'), h('div', { class: 'example' }, s.raw))); return; }
    body.append(h('div', { class: 'card' }, h('h2', null, '強み'), list(s.strengths)));
    body.append(h('div', { class: 'card' }, h('h2', null, '弱み'), list(s.weaknesses)));
    body.append(h('div', { class: 'card' }, h('h2', null, '次の練習テーマ'), list(s.nextThemes)));
    $('btnSummaryHistory').onclick = function () { showScreen('history'); showHistoryDetail(session.id); };
  }

  // ---------- S8 履歴 ----------
  function renderHistory() {
    var box = $('historyList'); clear(box);
    $('historyDetail').hidden = true; box.hidden = false;
    var items = AppStore.listSessions();
    if (!items.length) { box.append(h('p', { class: 'hint' }, 'まだ履歴がありません。')); return; }
    items.forEach(function (s) {
      box.append(h('div', { class: 'hist-item' },
        h('div', null, h('div', null, s.job + '(' + s.stage + ')'),
          h('div', { class: 'meta' }, fmtDate(s.startedAt) + ' ・ ' + (s.mode === 'mock' ? '模擬面接' : '質問練習') + ' ・ ' + s.turns.filter(function (t) { return t.role === 'candidate'; }).length + '回答')),
        h('div', { class: 'row' },
          h('button', { type: 'button', onclick: function () { showHistoryDetail(s.id); } }, '開く'),
          h('button', { type: 'button', class: 'danger', onclick: function () {
            if (!confirm('この履歴を削除しますか?')) return;
            try { AppStore.deleteSession(s.id); renderHistory(); } catch (e) { showError(e); }
          } }, '削除'))));
    });
  }

  function showHistoryDetail(id) {
    var s = AppStore.getSession(id);
    if (!s) return;
    var d = $('historyDetail'); clear(d);
    $('historyList').hidden = true; d.hidden = false;
    d.append(h('button', { type: 'button', class: 'link-btn', onclick: renderHistory }, '← 一覧へ戻る'),
      h('h2', null, s.job + '(' + s.stage + ') ・ ' + (s.mode === 'mock' ? '模擬面接' : '質問練習') + ' ・ ' + fmtDate(s.startedAt)));
    s.turns.forEach(function (t) {
      d.append(h('div', { class: 'bubble ' + (t.role === 'interviewer' ? 'interviewer' : 'candidate') },
        h('span', { class: 'who' }, t.role === 'interviewer' ? '面接官' : 'あなた'), t.text));
      var fb = t.feedback;
      if (fb && fb.raw) d.append(h('div', { class: 'card' }, h('div', { class: 'example' }, fb.raw)));
      else if (fb) {
        d.append(h('div', { class: 'card' },
          h('div', null, CONFIG.criteria.map(function (c) { return c + ' ' + (fb.scores && fb.scores[c]) + '/5　'; })),
          h('h2', null, '良い点'), list(fb.good || []), h('h2', null, '改善点'), list(fb.improve || []),
          h('h2', null, '改善例'), h('div', { class: 'example' }, fb.example || '')));
      }
    });
    if (s.summary) {
      var sm = s.summary;
      d.append(h('h2', null, '総評'));
      if (sm.raw) d.append(h('div', { class: 'example' }, sm.raw));
      else d.append(h('div', { class: 'card' }, h('h2', null, '強み'), list(sm.strengths || []), h('h2', null, '弱み'), list(sm.weaknesses || []), h('h2', null, '次の練習テーマ'), list(sm.nextThemes || [])));
    }
    window.scrollTo(0, 0);
  }

  // ---------- 初期化 ----------
  function init() {
    document.querySelectorAll('[data-goto]').forEach(function (b) {
      b.addEventListener('click', function () { showScreen(b.getAttribute('data-goto')); });
    });
    $('homeLink').addEventListener('click', function (e) {
      e.preventDefault();
      var inMock = !$('screen-mock').hidden && Mock.get().state !== 'idle' && Mock.get().state !== 'done';
      if (inMock && !confirm('模擬面接を中断してトップへ戻りますか?(ここまでの内容は履歴に残ります)')) return;
      if (inMock) Mock.abort(); else showScreen('home');
    });
    $('btnPractice').onclick = function () { mode = 'practice'; showScreen('setup'); };
    $('btnMock').onclick = function () { mode = 'mock'; showScreen('setup'); };
    $('btnHistory').onclick = function () { showScreen('history'); };
    $('btnSettings').onclick = function () { showScreen('settings'); };
    $('selJob').onchange = function () { $('lblJobFree').hidden = $('selJob').value !== '__free'; };
    $('btnStart').onclick = startFlow;
    counter($('practiceAnswer'), $('practiceCounter'));
    counter($('mockAnswer'), $('mockCounter'));
    $('btnSubmitAnswer').onclick = submitPractice;
    $('btnSkip').onclick = nextQuestion;
    $('btnEndPractice').onclick = function () { showScreen('home'); };
    $('btnRetryAnswer').onclick = function () { showQuestion(lastFeedbackAnswer); };
    $('btnNextQuestion').onclick = nextQuestion;
    $('btnMockSend').onclick = sendMock;
    $('btnMockFinish').onclick = function () {
      if (confirm('ここまでの内容で総評を作成します。よろしいですか?')) Mock.finishMock();
    };
    bindSettings();
    showScreen(AppStore.hasKey() ? 'home' : 'home');
  }

  window.UI = { init: init, showScreen: showScreen };
})();
