// 定数。モデル名などはここで差し替える(モデル名・問数は設定画面からも変更可)
window.CONFIG = {
  apiBase: 'https://generativelanguage.googleapis.com/v1beta/models/',
  // 無料枠の軽量モデルを想定。無料枠の変更に合わせて差し替えること(要: 公式ドキュメント確認)
  defaultModel: 'gemini-2.5-flash-lite',
  defaultQuestionCount: 5,
  maxQuestionCount: 10,          // 問数の上限
  timeoutMs: 40000,              // タイムアウト(ミリ秒)
  maxFollowups: 2,               // 1つの質問あたりの深掘り上限(仮置き)
  maxSessions: 200,              // 履歴の保存上限(仮置き)
  recentQuestionsForPrompt: 50,  // 重複回避のため渡す生成済み質問数
  recentTurnsForPrompt: 4,       // 模擬面接でAIへ送る直近ターン数
  maxAnswerChars: 3000,          // 回答の最大文字数
  temperatures: { question: 0.9, feedback: 0.2, interviewer: 0.7, summary: 0.2 },
  // 評価観点(5つ以内。変更可)
  criteria: ['結論', '具体性', '役割と成果', '職種との関連', '簡潔さ']
};
