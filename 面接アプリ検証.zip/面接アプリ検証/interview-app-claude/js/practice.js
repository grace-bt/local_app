// 質問練習の進行。UIは直接操作せず、結果を返す
(function () {
  function pad(n) { return String(n).padStart(2, '0'); }
  function localIso(d) {
    var off = -d.getTimezoneOffset(), sign = off >= 0 ? '+' : '-';
    off = Math.abs(off);
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + 'T' +
      pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds()) + sign + pad(Math.floor(off / 60)) + ':' + pad(off % 60);
  }
  function newSession(mode, job, stage) {
    var d = new Date();
    return {
      id: 's_' + d.getFullYear() + pad(d.getMonth() + 1) + pad(d.getDate()) + '_' + pad(d.getHours()) + pad(d.getMinutes()) + pad(d.getSeconds()),
      mode: mode, job: job, stage: stage, startedAt: localIso(d), turns: [], summary: null
    };
  }
  window.newSession = newSession;

  window.Practice = {
    // 質問を生成してコンテキストを返す
    startPractice: async function (job, stage, count) {
      var s = AppStore.getSettings();
      var past = AppStore.recentQuestions(job);
      var out = await Gemini.callJson('question', Prompts.buildQuestionPrompt({
        job: job, stage: stage, count: count, past: past, profile: s.profile, categories: Presets.categories
      }));
      var pastSet = {};
      past.forEach(function (t) { pastSet[t] = true; });
      var qs = out.questions.filter(function (q) { return !pastSet[q.text]; });
      if (!qs.length) qs = out.questions;
      qs = qs.slice(0, count);
      AppStore.addQuestions(qs, job);
      AppStore.saveSettings({ lastJob: job, lastStage: stage });
      return { session: newSession('practice', job, stage), questions: qs, added: {} };
    },

    // 回答を採点。format失敗時は生テキストを feedback.raw に入れて返す(回答は保存する)
    submitAnswer: async function (ctx, idx, answer) {
      var q = ctx.questions[idx];
      var s = AppStore.getSettings();
      var feedback;
      try {
        feedback = await Gemini.callJson('feedback', Prompts.buildFeedbackPrompt({
          job: ctx.session.job, stage: ctx.session.stage, question: q.text, answer: answer, profile: s.profile
        }));
      } catch (e) {
        if (e.kind !== 'format') throw e;
        feedback = { raw: e.raw };
      }
      if (!ctx.added[idx]) {
        ctx.session.turns.push({ role: 'interviewer', text: q.text, category: q.category });
        ctx.added[idx] = true;
      }
      ctx.session.turns.push({ role: 'candidate', text: answer, feedback: feedback });
      AppStore.upsertSession(ctx.session);
      return feedback;
    },

    // 再回答は同じ質問に対する submitAnswer と同じ処理
    retryAnswer: function (ctx, idx, answer) { return window.Practice.submitAnswer(ctx, idx, answer); }
  };
})();
