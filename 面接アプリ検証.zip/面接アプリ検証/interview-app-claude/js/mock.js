// 模擬面接の状態管理: idle → asking → waiting → asking … → summarizing → done (error あり)
(function () {
  var M = { state: 'idle', session: null, total: 0, asked: 0, followups: 0, pending: null, error: null, listener: null };

  function setState(s) {
    M.state = s;
    if (M.listener) M.listener(M);
  }
  function save() { AppStore.upsertSession(M.session); }

  function canNew() { return M.asked < M.total; }
  function canFollowup() { return M.asked > 0 && M.followups < CONFIG.maxFollowups; }

  // 直近の数ターン + それ以前の簡易要約(各発言の先頭だけ)
  function buildContext() {
    var turns = M.session.turns, n = CONFIG.recentTurnsForPrompt;
    var older = turns.slice(0, Math.max(0, turns.length - n));
    var recent = turns.slice(-n).map(function (t) { return { role: t.role, text: t.text.slice(0, 800) }; });
    var memo = older.map(function (t) {
      return (t.role === 'interviewer' ? '面接官' : '候補者') + ': ' + t.text.replace(/\s+/g, ' ').slice(0, 60) + (t.text.length > 60 ? '…' : '');
    }).join('\n');
    return { recent: recent, memo: memo };
  }

  async function doAsk() {
    setState('asking');
    M.pending = 'ask';
    var s = AppStore.getSettings(), c = buildContext();
    try {
      var out = await Gemini.callJson('interviewer', Prompts.buildInterviewerPrompt({
        job: M.session.job, stage: M.session.stage, profile: s.profile,
        total: M.total, asked: M.asked, followups: M.followups,
        canNew: canNew(), canFollowup: canFollowup(), first: M.asked === 0,
        recent: c.recent, memo: c.memo
      }));
      var type = out.type, end = out.end;
      if (M.asked === 0) { type = 'question'; end = false; }
      else if (type === 'question' && !canNew()) type = canFollowup() ? 'followup' : null;
      else if (type === 'followup' && !canFollowup()) type = canNew() ? 'question' : null;
      if (end || !type) return doSummary();
      if (type === 'question') { M.asked++; M.followups = 0; } else { M.followups++; }
      M.session.turns.push({ role: 'interviewer', text: out.text, kind: type });
      save();
      M.pending = null;
      setState('waiting');
    } catch (e) { fail(e); }
  }

  async function doSummary() {
    setState('summarizing');
    M.pending = 'summary';
    var s = AppStore.getSettings();
    try {
      var out = await Gemini.callJson('summary', Prompts.buildSummaryPrompt({
        job: M.session.job, stage: M.session.stage, profile: s.profile,
        turns: M.session.turns.map(function (t) { return { role: t.role, text: t.text.slice(0, 1200) }; })
      }));
      M.session.summary = out;
      save();
      M.pending = null;
      setState('done');
    } catch (e) {
      if (e.kind === 'format') { M.session.summary = { raw: e.raw }; save(); M.pending = null; setState('done'); }
      else fail(e);
    }
  }

  function fail(e) { M.error = e; setState('error'); }

  window.Mock = {
    get: function () { return M; },
    onChange: function (fn) { M.listener = fn; },

    startMock: function (job, stage, total) {
      M.session = newSession('mock', job, stage);
      M.total = total; M.asked = 0; M.followups = 0; M.error = null; M.pending = null;
      AppStore.saveSettings({ lastJob: job, lastStage: stage });
      return doAsk();
    },

    // 候補者の回答を送信。回答はその場で履歴へ保存される(エラー時も保持)
    sendAnswer: function (text) {
      if (M.state !== 'waiting') return Promise.resolve();
      M.session.turns.push({ role: 'candidate', text: text });
      save();
      if (!canNew() && !canFollowup()) return doSummary();
      return doAsk();
    },

    // 途中終了。ここまでの内容で総評を作る
    finishMock: function () {
      if (M.state !== 'waiting') return Promise.resolve();
      var answered = M.session.turns.some(function (t) { return t.role === 'candidate'; });
      if (!answered) { AppStore.deleteSession(M.session.id); setState('idle'); return Promise.resolve(); }
      return doSummary();
    },

    // エラー後に直前の処理を再試行
    retry: function () {
      if (M.state !== 'error') return Promise.resolve();
      M.error = null;
      return M.pending === 'summary' ? doSummary() : doAsk();
    },

    abort: function () { M.error = null; M.pending = null; setState('idle'); }
  };
})();
