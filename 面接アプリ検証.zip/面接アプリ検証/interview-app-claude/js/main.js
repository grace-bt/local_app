// 起動処理。キー未設定ならトップの案内(練習ボタン無効+注意書き)から設定画面へ誘導する
document.addEventListener('DOMContentLoaded', function () {
  UI.init();
});
