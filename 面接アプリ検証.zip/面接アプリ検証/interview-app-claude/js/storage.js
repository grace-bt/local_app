// localStorageの読み書き。他モジュールはlocalStorageを直接触らない
(function () {
  var KEYS = { settings: 'ib.settings', sessions: 'ib.sessions', questions: 'ib.questions' };

  function read(key, def) {
    try {
      var s = localStorage.getItem(key);
      return s ? JSON.parse(s) : def;
    } catch (e) { return def; }
  }
  function write(key, val) {
    try {
      localStorage.setItem(key, JSON.stringify(val));
    } catch (e) {
      var err = new Error('保存できませんでした。履歴をエクスポートして、古い履歴を削除してください。');
      err.kind = 'storage';
      throw err;
    }
  }

  function defaults() {
    return {
      apiKey: '', model: CONFIG.defaultModel, questionCount: CONFIG.defaultQuestionCount,
      lastJob: '', lastStage: '',
      profile: { job: '', career: '', motive: '', strengths: '' }
    };
  }

  var Storage = {
    getSettings: function () {
      var s = Object.assign(defaults(), read(KEYS.settings, {}));
      s.profile = Object.assign(defaults().profile, s.profile || {});
      return s;
    },
    saveSettings: function (patch) {
      var s = Object.assign(Storage.getSettings(), patch);
      write(KEYS.settings, s);
      return s;
    },
    hasKey: function () { return !!Storage.getSettings().apiKey; },
    listSessions: function () { return read(KEYS.sessions, []); },
    getSession: function (id) {
      return Storage.listSessions().filter(function (s) { return s.id === id; })[0] || null;
    },
    upsertSession: function (session) {
      var list = Storage.listSessions();
      var i = list.findIndex(function (s) { return s.id === session.id; });
      if (i >= 0) list[i] = session; else list.unshift(session);
      list.sort(function (a, b) { return a.startedAt < b.startedAt ? 1 : -1; });
      write(KEYS.sessions, list.slice(0, CONFIG.maxSessions));
    },
    deleteSession: function (id) {
      write(KEYS.sessions, Storage.listSessions().filter(function (s) { return s.id !== id; }));
    },
    listQuestions: function () { return read(KEYS.questions, []); },
    recentQuestions: function (job, n) {
      return Storage.listQuestions().filter(function (q) { return q.job === job; })
        .slice(-(n || CONFIG.recentQuestionsForPrompt)).map(function (q) { return q.text; });
    },
    addQuestions: function (items, job) {
      var list = Storage.listQuestions();
      var now = new Date().toISOString();
      items.forEach(function (q) { list.push({ text: q.text, job: job, category: q.category, createdAt: now }); });
      write(KEYS.questions, list.slice(-500));
    },
    // APIキーを含めない
    exportAll: function () {
      return JSON.stringify({
        app: 'interview-app', version: 1, exportedAt: new Date().toISOString(),
        sessions: Storage.listSessions(), questions: Storage.listQuestions()
      }, null, 2);
    },
    importAll: function (text) {
      var data;
      try { data = JSON.parse(text); } catch (e) { throw new Error('JSONとして読み込めませんでした。'); }
      if (!data || !Array.isArray(data.sessions)) throw new Error('このアプリのエクスポートファイルではありません。');
      var cur = Storage.listSessions();
      var ids = {};
      cur.forEach(function (s) { ids[s.id] = true; });
      var added = 0;
      data.sessions.forEach(function (s) {
        if (s && typeof s.id === 'string' && Array.isArray(s.turns) && !ids[s.id]) { cur.push(s); added++; }
      });
      cur.sort(function (a, b) { return a.startedAt < b.startedAt ? 1 : -1; });
      write(KEYS.sessions, cur.slice(0, CONFIG.maxSessions));
      if (Array.isArray(data.questions)) {
        var qs = Storage.listQuestions();
        var seen = {};
        qs.forEach(function (q) { seen[q.job + '|' + q.text] = true; });
        data.questions.forEach(function (q) {
          if (q && typeof q.text === 'string' && !seen[q.job + '|' + q.text]) qs.push(q);
        });
        write(KEYS.questions, qs.slice(-500));
      }
      return added;
    },
    clearKey: function () { Storage.saveSettings({ apiKey: '' }); },
    clearAll: function () {
      try { Object.keys(KEYS).forEach(function (k) { localStorage.removeItem(KEYS[k]); }); } catch (e) { /* noop */ }
    }
  };
  window.AppStore = Storage; // window.Storage(ブラウザ組み込み)と衝突しない名前にする
})();
