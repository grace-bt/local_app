# 面接対策アプリ

転職面接の回答練習を、AIフィードバックと模擬面接で繰り返せるローカルWebアプリです。

## 使い方(Windows / Edge・Chrome 最新版)

1. このフォルダの `index.html` をダブルクリックして開く(Python・Nodeなどのインストールは不要)
2. 「設定」で [Google AI Studio](https://aistudio.google.com/apikey) のGemini APIキーを入力し、「接続テストして保存」
3. 「質問練習」または「模擬面接」を選び、職種・面接段階・問数を決めて開始

## 注意書き

- 入力した内容は Google の Gemini API に送信されます。無料枠では入力内容がサービス改善に利用される場合があるため、**社名・個人情報・社外秘は入力しないでください**。詳細は公式の規約を確認してください(※公開前に規約を確認して文言を調整すること)。
- APIキー・設定・履歴はこのブラウザの localStorage にのみ保存され、Gemini 以外には送信されません。キーは各自のPCでのみ使う前提です。共用PCでは設定画面の「キーと履歴をすべて削除」を使ってください。
- 履歴はブラウザのデータ削除で消えます。設定画面から定期的にエクスポートしてください(エクスポートにAPIキーは含まれません)。
- スコアは練習の目安であり、合否の判定ではありません。

## 設定値

- モデル名・問数: 設定画面、または `js/config.js`(初期値 `gemini-2.5-flash-lite`。無料枠で使えるモデルと制限は公式ドキュメントで確認して差し替えてください)
- 評価観点(5つ以内)・深掘り回数・タイムアウト: `js/config.js`
- プロンプト文言: `js/prompts.js`
- 職種・面接段階: `js/presets.js`

## 構成

`index.html` / `css/style.css` / `js/`(config → presets → storage → prompts → gemini → practice → mock → ui → main の順に読み込み)。外部ライブラリ・CDNは使いません。

## 動作確認が必要な点(設計書 第13章)

- `file://` から Gemini API を呼べるか(CORS)
- `file://` での localStorage が再起動後も残るか
- Gemini API の最新仕様(エンドポイント・ヘッダー・JSON出力指定)
