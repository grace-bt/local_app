@echo off
chcp 65001 >nul
cd /d "%~dp0"

rem ---- 1. Python を探す(py ランチャー → python の順) ----
set PY=
py -3 --version >nul 2>&1 && set PY=py -3
if not defined PY (
  python --version >nul 2>&1 && set PY=python
)
if not defined PY (
  echo [エラー] Python が見つかりません。
  echo README の「1. Python をインストール」を実施してから、もう一度ダブルクリックしてください。
  start https://www.python.org/downloads/windows/
  pause
  exit /b 1
)

rem ---- 2. 初回だけ: 専用環境(.venv)を作って部品を入れる ----
if not exist ".venv\Scripts\python.exe" (
  echo 初回セットアップ中です。数分かかることがあります...
  %PY% -m venv .venv
  if errorlevel 1 ( echo [エラー] 環境の作成に失敗しました。 & pause & exit /b 1 )
)
rem 部品は毎回確認する(導入済みなら数秒で終わる。中断・追加分も自動で補完される)
".venv\Scripts\python.exe" -m pip install -r requirements.txt -q
if errorlevel 1 ( echo [エラー] 部品のインストールに失敗しました。 & pause & exit /b 1 )

rem ---- 3. 初回だけ: .env を作る ----
if not exist ".env" (
  copy ".env.example" ".env" >nul
  echo .env を作成しました。メモ帳で開いて GEMINI_API_KEY を入力してください。
  start notepad ".env"
)

rem ---- 4. 起動 ----
".venv\Scripts\python.exe" app.py
pause
