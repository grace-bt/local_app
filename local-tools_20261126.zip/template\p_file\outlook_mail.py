import os, win32com.client, subprocess, time
from dotenv import load_dotenv
from google import genai
from google.genai import errors
import pythoncom

from p_file.organaize_file import UserFacingError  # app.py と同じクラスを使う(捕捉漏れ防止)

load_dotenv()

def generate_text(prompt: str, max_retries: int = 5) -> str:
    api_key = os.getenv("GEMINI_API_KEY")
    model = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
    if not api_key:
        raise UserFacingError("GEMINI_API_KEY が設定されていません。.env を確認してください。")

    client = genai.Client(api_key=api_key)
    for attempt in range(max_retries):
        try:
            response = client.models.generate_content(model=model, contents=prompt)
            return response.text or ""
        except errors.APIError as e:
            # 一時的なエラーのみ再試行
            if e.code in (429, 500, 503) and attempt < max_retries - 1:
                wait = 2 ** attempt  # 1, 2, 4, 8秒
                print(f"{e.code} 再試行 {attempt + 1}/{max_retries} ({wait}秒待機)")
                time.sleep(wait)
                continue
            raise

#outlookが残っているかの確認
def is_outlook_running():
    out = subprocess.run(
        ["tasklist", "/FI", "IMAGENAME eq OUTLOOK.EXE"],
        capture_output=True
    ).stdout
    return b"OUTLOOK.EXE" in out.upper()

#outlook起動
def get_outlook(restart=False):
    if is_outlook_running():
        if not restart:
            return win32com.client.GetActiveObject("Outlook.Application") 
        try:
            win32com.client.GetActiveObject("Outlook.Application").Quit()
        except Exception:
            pass
        for _ in range(10):
            if not is_outlook_running():
                break
            time.sleep(1)
        if is_outlook_running():
            subprocess.run(["taskkill", "/F", "/IM", "OUTLOOK.EXE"], capture_output=True)
            time.sleep(2)
    return win32com.client.Dispatch("Outlook.Application")

#未読メール取得(未読メール文繰り返す)
def make_mail(app):
    inbox = app.GetNamespace("MAPI").GetDefaultFolder(6) 
    unread_messages = inbox.Items.Restrict("[UnRead] = True")
    count = 0

    for message in unread_messages:
        try:
            # 各種情報の取得
            mail = app.CreateItem(0) 
            to_adress = message.SenderEmailAddress #送信元アドレス
            cc_adress = message.CC  #Cc
            subject = message.Subject  # 件名
            body = message.Body # 本文

            #返信文作成
            body = generate_text("本文を元にメールの返信文を作成してください。作成した返信文以外出力しないでください。本文:" + body)
            mail.To = to_adress
            mail.CC = cc_adress
            mail.Subject = "Re:" + subject
            mail.Body = body
            #下書き保存
            mail.Save()
            count += 1
        except UserFacingError:
            raise  # APIキー未設定などは全体を止めて画面に伝える
        except Exception as e:
            #エラー時はスキップ
            print(f"エラー出力: {e}")
            continue
    return count

#自分で起動した場合のみOutlookを閉じる。作成した下書き件数を返す
def outlook_mail() -> int:
    pythoncom.CoInitialize()  # Flaskは別スレッドで動くためCOMの初期化が必要
    started_by_us = not is_outlook_running()
    app = None
    try:
        app = get_outlook()
        return make_mail(app)
    except UserFacingError:
        raise
    except Exception as e:
        raise UserFacingError(f"Outlookの処理に失敗しました: {e}")
    finally:
        if started_by_us and app is not None:
            try:
                app.Quit()
            except Exception:
                pass
        app = None
        pythoncom.CoUninitialize()